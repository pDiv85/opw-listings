"""Live-check plantation adverts that did not turn up in this run's search sweep.

A listing comes off the website only on evidence that it is sold or withdrawn:
  * the advert page returns 404/410, or redirects away from the advert (sites do this once an ad ends)
  * the page says the property is sold / the ad has expired (marker phrases in config/sources.yml)
If the site refuses the check (403, bot challenge), the result is 'could not check' and the listing stays.
A listing is removed only after two checks in a row agree (one blip or a mis-read page never removes it).
"""
from __future__ import annotations

import logging
import re
from datetime import timedelta
from urllib.parse import urlparse

import requests

from .common import Blocked, fold, iso, parse_iso

log = logging.getLogger("opw")

DEFAULT_SOLD = ["this property has been sold", "this listing has been sold", "property sold", "status: sold",
                "telah dijual", "sudah dijual", "sudah terjual", "vendido", "vendue", "sold out"]
DEFAULT_GONE = ["no longer available", "is no longer active", "has expired", "ad has been removed",
                "listing not found", "tidak lagi tersedia", "iklan telah tamat", "iklan ini tidak", "tidak ditemui",
                "ya no esta publicado", "ya no esta disponible", "n'est plus disponible", "page not found"]


def _listing_token(url: str) -> str:
    """The numeric/hex id at the end of an advert URL, used to tell a redirect-to-search from a canonical move."""
    m = re.search(r"([0-9A-F]{32}|\d{6,})(?:\.htm)?/?$", urlparse(url).path, re.I)
    return m.group(1).lower() if m else urlparse(url).path.rstrip("/").lower()


def classify(url: str, status: int, final_url: str, text: str, sold: list[str], gone: list[str]) -> str:
    if status in (404, 410):
        return "no longer listed on the source site"
    if status >= 400:
        return "unknown"
    if _listing_token(url) not in (final_url or "").lower():
        return "no longer listed on the source site"
    body = fold(re.sub(r"<script.*?</script>|<style.*?</style>", " ", text or "", flags=re.S | re.I))
    if any(fold(m) in body for m in sold):
        return "sold"
    if any(fold(m) in body for m in gone):
        return "no longer listed on the source site"
    return "live"


def run(store, kind: str, reg: dict, http, cfg: dict, now) -> dict:
    """Checks up to `max_checks_per_run` stale listings, oldest check first. Mutates and saves reg."""
    if not cfg or not cfg.get("enabled", True):
        return {}
    sold = cfg.get("sold_markers") or DEFAULT_SOLD
    gone = cfg.get("gone_markers") or DEFAULT_GONE
    recheck = timedelta(hours=float(cfg.get("recheck_after_hours", 24)))
    now_s = iso(now)
    due = []
    for rec in reg.values():
        if rec.get("status") != "active" or not rec.get("url", "").startswith("http"):
            continue
        if rec.get("last_seen") == now_s:
            continue                                    # found in this run's sweep: live
        lv = parse_iso(rec.get("last_checked_at") or rec.get("last_verified"))
        if lv and now - lv < recheck and not rec.get("gone_strikes"):
            continue                                    # a pending strike is re-checked on the next run
        due.append(rec)
    due.sort(key=lambda r: (-(r.get("gone_strikes") or 0), -(r.get("misses") or 0),
                            r.get("last_checked_at") or r.get("last_seen") or ""))
    stats = {"checked": 0, "live": 0, "sold": 0, "gone": 0, "could_not_check": 0}
    blocked_hosts: set[str] = set()
    for rec in due[: int(cfg.get("max_checks_per_run", 80))]:
        host = urlparse(rec["url"]).netloc
        if host in blocked_hosts:
            stats["could_not_check"] += 1
            continue
        try:
            status, final, text = http.probe(rec["url"])
        except Blocked as exc:
            blocked_hosts.add(host)
            stats["could_not_check"] += 1
            log.info("verify: %s refuses page checks (%s)", host, exc)
            continue
        except requests.RequestException:
            stats["could_not_check"] += 1
            continue
        stats["checked"] += 1
        rec["last_checked_at"] = now_s
        outcome = classify(rec["url"], status, final, text, sold, gone)
        if outcome == "live":
            rec["last_verified"] = now_s
            rec["misses"] = 0
            rec.pop("gone_strikes", None)
            stats["live"] += 1
        elif outcome == "unknown":
            stats["could_not_check"] += 1
        else:
            rec["gone_strikes"] = rec.get("gone_strikes", 0) + 1
            if rec["gone_strikes"] >= int(cfg.get("confirmations", 2)):
                store.remove(kind, rec, outcome, now)
                stats["sold" if outcome == "sold" else "gone"] += 1
            else:
                stats["pending_confirmation"] = stats.get("pending_confirmation", 0) + 1
    store.save(kind, reg)
    return stats
