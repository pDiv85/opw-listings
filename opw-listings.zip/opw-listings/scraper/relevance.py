"""Is this listing actually about oil palm? Keyword lists live in config/sources.yml so they can be tuned
without touching code; the defaults below are used when the config leaves them out."""
from __future__ import annotations

import re

from .common import fold

DEFAULT_JOB_RULES = {
    "strong": [
        "palm", "sawit", "kelapa sawit", "oil palm", "palm oil", "cpo", "ffb", "tbs", "pks", "pom",
        "kernel", "palma", "palmera", "palmier", "huile de palme", "aceite de palma", "extractora",
        "edible oil", "oleochemical", "oleokimia", "minyak sawit", "planta extractora", "elaeis",
    ],
    "plantation": [
        "plantation", "plantations", "perkebunan", "ladang", "estate", "kebun", "afdeling",
        "plantacion", "plantaciones", "hacienda", "agroindustria",
    ],
    "companies": [
        "wilmar", "sd guthrie", "sime darby plantation", "ioi corporation", "ioi plantation", "klk",
        "kuala lumpur kepong", "fgv", "felda", "genting plantations", "sawit kinabalu", "boustead",
        "tsh resources", "hap seng plantations", "sarawak oil palms", "ta ann", "united plantations",
        "kim loong", "kwantas", "johor plantations", "ijm plantations", "pgeo",
        "astra agro", "sinar mas", "smart tbk", "golden agri", "triputra", "musim mas", "asian agri",
        "first resources", "bumitama", "sampoerna agro", "dharma satya", "eagle high", "austindo",
        "cargill", "bunge", "olam", "socfin", "siat", "presco", "okomu", "nbpol", "new britain palm",
        "poligrow", "daabon", "indupalma", "palmas", "agroaceite", "repsa", "olmeca", "dinant",
        "jaremar", "palmasa", "palmeras del ecuador", "sapet", "palmagro",
    ],
    "exclude": [
        "rubber", "getah", "durian", "musang king", "poultry", "floriculture", "flower", "mall",
        "aquaponic", "real estate", "estate agent", "estate planning", "property agent", "hotel",
        "sugar", "cocoa", "banana", "pineapple", "nanas", "tea estate", "coffee", "aquaculture",
    ],
}

DEFAULT_PLANTATION_RULES = {
    "palm": ["sawit", "palm", "kelapa", "palma", "palmier", "elaeis"],
    "exclude": ["durian", "rubber only", "getah sahaja", "rumah teres", "condo", "apartment", "shoplot"],
}


def _has(terms, text: str) -> str | None:
    t = " " + re.sub(r"[^a-z0-9]+", " ", fold(text)) + " "
    for term in terms:
        if f" {re.sub(r'[^a-z0-9]+', ' ', fold(term)).strip()} " in t:
            return term
    return None


def job_match(rules: dict, title: str, company: str, teaser: str = "", trust_search: bool = False) -> str | None:
    """Returns the reason a job qualifies ('title', 'description', 'company', 'search') or None."""
    r = {**DEFAULT_JOB_RULES, **(rules or {})}
    head = f"{title} {teaser}"
    strong_title = _has(r["strong"], title)
    strong_any = strong_title or _has(r["strong"], f"{teaser} {company}")
    excluded = _has(r["exclude"], f"{title} {teaser} {company}")
    if excluded and not strong_title and not _has(r["strong"], teaser):
        return None
    if strong_title:
        return "title"
    if strong_any:
        return "description"
    if _has(r["companies"], company):
        return "company"
    if _has(r["plantation"], f"{head} {company}"):
        return "plantation"
    if trust_search:
        return "search"
    return None


def plantation_match(rules: dict, title: str, extra: str = "") -> dict | None:
    r = {**DEFAULT_PLANTATION_RULES, **(rules or {})}
    if _has(r["exclude"], title) and not _has(r["palm"], title):
        return None
    if _has(r["palm"], title):
        return {"palm_signal": "title"}
    if _has(r["palm"], extra):
        return {"palm_signal": "details"}
    return {"palm_signal": "search"}     # site matched our palm keyword in the full description
