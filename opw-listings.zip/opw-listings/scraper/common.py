"""Shared helpers: HTTP, text normalisation, dates, money and area parsing."""
from __future__ import annotations

import hashlib
import logging
import re
import time
import unicodedata
from datetime import datetime, timedelta, timezone

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

log = logging.getLogger("opw")

UTC = timezone.utc


def now_utc() -> datetime:
    return datetime.now(UTC).replace(microsecond=0)


def iso(dt: datetime | None) -> str | None:
    if dt is None:
        return None
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_iso(value: str | None) -> datetime | None:
    if not value:
        return None
    value = value.strip()
    for fmt in ("%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%d"):
        try:
            return datetime.strptime(value, fmt).replace(tzinfo=UTC)
        except ValueError:
            pass
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=UTC)
    except ValueError:
        return None


# --------------------------------------------------------------------------- HTTP

class Blocked(Exception):
    """The site refused us (403/429, bot challenge, sign-in wall). We never try to get round it."""


BLOCK_MARKERS = (
    "cf-chl", "challenge-platform", "Just a moment...", "Attention Required!",
    "captcha", "px-captcha", "Access Denied", "Request unsuccessful. Incapsula",
)


class Http:
    def __init__(self, user_agent: str, delay: float = 2.0, timeout: int = 30):
        self.delay = delay
        self.timeout = timeout
        self._last = 0.0
        self.s = requests.Session()
        retry = Retry(total=3, backoff_factor=2, status_forcelist=(500, 502, 504),
                      allowed_methods=("GET",), raise_on_status=False)
        self.s.mount("https://", HTTPAdapter(max_retries=retry))
        self.s.headers.update({
            "User-Agent": user_agent,
            "Accept-Language": "en-GB,en;q=0.9,ms;q=0.8,id;q=0.7,es;q=0.6",
        })

    def get(self, url: str, *, params=None, headers=None, expect_json=False):
        wait = self.delay - (time.monotonic() - self._last)
        if wait > 0:
            time.sleep(wait)
        self._last = time.monotonic()
        r = self.s.get(url, params=params, headers=headers, timeout=self.timeout)
        if r.status_code in (401, 403, 429, 503):
            raise Blocked(f"HTTP {r.status_code} from {r.url[:120]}")
        r.raise_for_status()
        if expect_json:
            try:
                return r.json()
            except ValueError as exc:
                raise Blocked(f"Expected JSON but got HTML from {r.url[:120]}") from exc
        text = r.text
        head = text[:4000]
        if any(m in head for m in BLOCK_MARKERS):
            raise Blocked(f"Bot challenge page at {r.url[:120]}")
        return text

    def probe(self, url: str) -> tuple[int, str, str]:
        """Open one advert page to see whether it is still live. Returns (status, final_url, text);
        404/410 are returned, not raised. Refusals raise Blocked, i.e. 'could not check'."""
        wait = self.delay - (time.monotonic() - self._last)
        if wait > 0:
            time.sleep(wait)
        self._last = time.monotonic()
        r = self.s.get(url, timeout=self.timeout, allow_redirects=True)
        if r.status_code in (401, 403, 429, 503):
            raise Blocked(f"HTTP {r.status_code} from {r.url[:120]}")
        text = r.text[:400_000] if r.status_code < 400 else ""
        if any(m in text[:4000] for m in BLOCK_MARKERS):
            raise Blocked(f"Bot challenge page at {r.url[:120]}")
        return r.status_code, r.url, text


# --------------------------------------------------------------------------- text

def clean(s) -> str:
    if s is None:
        return ""
    s = str(s).replace("\xa0", " ")
    return re.sub(r"\s+", " ", s).strip()


def fold(s: str) -> str:
    """Lower-case, strip accents — for matching and fingerprints."""
    s = unicodedata.normalize("NFKD", clean(s).lower())
    return "".join(ch for ch in s if not unicodedata.combining(ch))


def slug_key(*parts) -> str:
    txt = "|".join(re.sub(r"[^a-z0-9]+", " ", fold(p or "")).strip() for p in parts)
    return hashlib.sha1(txt.encode()).hexdigest()[:16]


# --------------------------------------------------------------------------- relative dates

_UNITS = {
    "minute": 1 / 1440, "min": 1 / 1440, "minit": 1 / 1440, "menit": 1 / 1440, "minuto": 1 / 1440,
    "hour": 1 / 24, "hr": 1 / 24, "h": 1 / 24, "jam": 1 / 24, "hora": 1 / 24, "heure": 1 / 24,
    "day": 1, "d": 1, "hari": 1, "dia": 1, "jour": 1, "jours": 1,
    "week": 7, "w": 7, "minggu": 7, "semana": 7, "semaine": 7,
    "month": 30, "mo": 30, "bulan": 30, "mes": 30, "mois": 30,
}
_REL = re.compile(r"(\d+)\s*\+?\s*([a-z]+)")


def relative_to_date(text: str, now: datetime) -> datetime | None:
    """'Listed 5 days ago', '2d ago', 'Hace 21 horas', '3 hari yang lalu', 'il y a 2 jours'."""
    t = fold(text)
    if not t:
        return None
    if any(w in t for w in ("just now", "baru saja", "today", "hari ini", "hoy", "aujourd")):
        return now
    if any(w in t for w in ("yesterday", "semalam", "kemarin", "ayer", "hier")):
        return now - timedelta(days=1)
    for num, unit in _REL.findall(t):
        unit_key = unit.rstrip("s") if unit.rstrip("s") in _UNITS else unit
        for key, days in _UNITS.items():
            if unit_key == key or (len(key) > 2 and unit_key.startswith(key)):
                return now - timedelta(days=int(num) * days)
    return None


# --------------------------------------------------------------------------- money

def parse_amount(s: str, single_dot_decimal: bool = False) -> float | None:
    """'2,900' '12.000.000' '8.000.000,00' '1.5 juta' '2.9 million' -> float.

    A lone '.' followed by three digits is read as a thousands separator (Rp 4.500) unless
    single_dot_decimal is set, as for land areas (2.144 ekar)."""
    s = fold(s)
    m = re.search(r"\d[\d.,\s]*", s)
    if not m:
        return None
    num = m.group(0).strip().replace(" ", "")
    tail = s[m.end():m.end() + 12]
    if "," in num and "." in num:
        dec = "," if num.rfind(",") > num.rfind(".") else "."
        num = num.replace("." if dec == "," else ",", "").replace(dec, ".")
    elif "," in num or "." in num:
        sep = "," if "," in num else "."
        parts = num.split(sep)
        if len(parts) > 2 or (len(parts) == 2 and len(parts[1]) == 3 and not (sep == "." and single_dot_decimal)):
            num = num.replace(sep, "")
        else:
            num = num.replace(",", ".")
    try:
        val = float(num.rstrip("."))
    except ValueError:
        return None
    if re.match(r"\s*(k|rb|ribu)\b", tail):
        val *= 1_000
    elif re.match(r"\s*(m|mil|million|juta|jt)\b", tail):
        val *= 1_000_000
    elif re.match(r"\s*(b|bil|billion|miliar)\b", tail):
        val *= 1_000_000_000
    return val


CURRENCY_HINTS = [
    ("RM", "MYR"), ("MYR", "MYR"), ("RP", "IDR"), ("IDR", "IDR"), ("THB", "THB"), ("฿", "THB"),
    ("PGK", "PGK"), ("NGN", "NGN"), ("₦", "NGN"), ("GHS", "GHS"), ("XOF", "XOF"),
    ("FCFA", "XOF"), ("COP", "COP"), ("PEN", "PEN"), ("S/", "PEN"), ("GTQ", "GTQ"),
    ("HNL", "HNL"), ("USD", "USD"), ("US$", "USD"), ("INR", "INR"), ("₹", "INR"),
    ("LKR", "LKR"), ("MXN", "MXN"), ("CRC", "CRC"), ("₡", "CRC"),
]
COUNTRY_CURRENCY = {
    "Malaysia": "MYR", "Indonesia": "IDR", "Thailand": "THB", "Papua New Guinea": "PGK",
    "Nigeria": "NGN", "Ghana": "GHS", "Ivory Coast": "XOF", "Colombia": "COP", "Peru": "PEN",
    "Guatemala": "GTQ", "Honduras": "HNL", "Ecuador": "USD", "India": "INR", "Sri Lanka": "LKR",
    "Mexico": "MXN", "Costa Rica": "CRC", "Panama": "USD",
}


def parse_salary(text: str, country: str = "") -> dict:
    """Returns salary_text/min/max/currency/period. Never invents a figure."""
    out = {"salary_text": clean(text) or "Not disclosed", "salary_min": None, "salary_max": None,
           "salary_currency": None, "salary_period": None}
    t = clean(text)
    if not t or not re.search(r"\d", t):
        out["salary_text"] = "Not disclosed" if not t else t
        return out
    up = t.upper() + " "
    cur = next((code for hint, code in CURRENCY_HINTS if hint in up), None)
    if cur is None and "$" in t:
        cur = COUNTRY_CURRENCY.get(country) if country in ("Colombia", "Mexico", "Ecuador", "Panama") else "USD"
    out["salary_currency"] = cur or COUNTRY_CURRENCY.get(country)
    pieces = re.split(r"\s(?:–|-|to|a|hingga|sampai|—)\s", t)
    nums = [parse_amount(p) for p in pieces[:2]]
    nums = [n for n in nums if n]
    if nums:
        out["salary_min"], out["salary_max"] = min(nums), max(nums)
    f = fold(t)
    if any(w in f for w in ("month", "bulan", "mensual", "mes", "mois", "/mo")):
        out["salary_period"] = "month"
    elif any(w in f for w in ("year", "annum", "tahun", "anual", "/yr")):
        out["salary_period"] = "year"
    elif any(w in f for w in ("hour", "jam", "hora")):
        out["salary_period"] = "hour"
    elif any(w in f for w in ("day", "hari", "diario", "jour")):
        out["salary_period"] = "day"
    return out


# --------------------------------------------------------------------------- area

ACRES_PER = {
    "acre": 1.0, "ac": 1.0, "ekar": 1.0,
    "hectare": 2.4710538, "ha": 2.4710538, "hektar": 2.4710538, "hectarea": 2.4710538,
    "sqft": 1 / 43560, "sq ft": 1 / 43560, "sf": 1 / 43560,
    "sqm": 1 / 4046.856, "m2": 1 / 4046.856, "m²": 1 / 4046.856,
    "manzana": 1.7267, "mz": 1.7267,          # Central America, 0.6988 ha
    "caballeria": 111.49,                     # Guatemala, 45.12 ha
    "relong": 0.7116,                         # Kedah/Perlis, 0.288 ha
}
_AREA = re.compile(
    r"(\d[\d.,]*)\s*(acres?|ac\b|ekar|hectares?|hect[aá]reas?|hektar|ha\b|sq\.?\s?ft|sqft|sf\b|sqm|m2|m²|"
    r"manzanas?|mz\b|caballer[ií]as?|relong)", re.I)


def parse_area_acres(text: str) -> float | None:
    m = _AREA.search(text or "")
    if not m:
        return None
    val = parse_amount(m.group(1), single_dot_decimal=True)
    unit = fold(m.group(2)).replace(".", "").rstrip("s")
    unit = {"hectarea": "hectarea", "hectare": "hectare", "acre": "acre", "manzana": "manzana",
            "caballeria": "caballeria"}.get(unit, unit)
    for key, factor in ACRES_PER.items():
        if unit == key or unit.replace(" ", "") == key.replace(" ", "") or unit.startswith(key):
            return round(val * factor, 4) if val else None
    return None
