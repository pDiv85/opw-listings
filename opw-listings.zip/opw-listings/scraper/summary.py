"""Prints a Markdown run summary (shown on the GitHub Actions run page)."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def main():
    st = json.loads((ROOT / "data" / "status.json").read_text())
    run = st["runs"][0] if st.get("runs") else {}
    print(f"## OPW listings refresh — {st.get('generated_at')}\n")
    print(f"Published: **{run.get('jobs_published', '–')} jobs** (last 30 days), "
          f"**{run.get('plantations_published', '–')} plantations** (live on their source sites)\n")
    v = run.get("plantations_verification")
    if v:
        print(f"Plantation live-checks: {v.get('checked', 0)} pages checked · {v.get('live', 0)} still live · "
              f"{v.get('sold', 0)} sold · {v.get('gone', 0)} withdrawn · {v.get('pending_confirmation', 0)} awaiting "
              f"a second check · {v.get('could_not_check', 0)} could not be checked\n")
    print("| Source | Type | Status | Found this run | Last success | Note |\n|---|---|---|---|---|---|")
    icon = {"ok": "✅ ok", "blocked": "⛔ blocked", "error": "❌ error", "disabled": "⏸ disabled"}
    for sid, s in sorted(st["sources"].items(), key=lambda kv: (kv[1].get("kind", ""), kv[0])):
        print(f"| {s.get('name', sid)} | {s.get('kind', '')} | {icon.get(s.get('status'), s.get('status'))} | "
              f"{s.get('count', '') if s.get('status') == 'ok' else ''} | {s.get('last_ok') or '–'} | "
              f"{(s.get('message') or '').replace('|', '/')[:120]} |")


if __name__ == "__main__":
    main()
