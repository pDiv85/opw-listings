"""Entry point:  python -m scraper.run  [--kind jobs|plantations] [--source ID ...] [--offline]

Each source runs in isolation: a blocked or broken site is recorded in data/status.json and its
existing listings are left untouched, so one failure never empties the website.
"""
from __future__ import annotations

import argparse
import json
import logging
import os
import sys
import traceback
from datetime import timedelta
from pathlib import Path

import requests
import yaml

from .common import Blocked, Http, iso, now_utc, parse_iso
from .sources import FETCHERS
from .store import Store
from . import verify

ROOT = Path(__file__).resolve().parent.parent
log = logging.getLogger("opw")

COUNTRY_CODES = {"MY": "Malaysia", "ID": "Indonesia", "TH": "Thailand", "PG": "Papua New Guinea",
                 "SG": "Singapore", "PH": "Philippines", "VN": "Vietnam", "IN": "India", "LK": "Sri Lanka",
                 "NG": "Nigeria", "GH": "Ghana", "CI": "Ivory Coast", "SL": "Sierra Leone", "CG": "Congo",
                 "CD": "DR Congo", "CM": "Cameroon", "LR": "Liberia", "CO": "Colombia", "PE": "Peru",
                 "EC": "Ecuador", "GT": "Guatemala", "HN": "Honduras", "NI": "Nicaragua", "CR": "Costa Rica",
                 "MX": "Mexico", "PA": "Panama", "BR": "Brazil"}


class Ctx:
    def __init__(self, cfg: dict, now):
        s = cfg["settings"]
        self.root = ROOT
        self.now = now
        self.window_days = int(cfg["jobs"].get("max_age_days") or 30)        # jobs search window
        self.cutoff = now - timedelta(days=self.window_days)
        p_age = cfg["plantations"].get("max_age_days")
        self.cutoffs = {"jobs": self.cutoff, "plantations": now - timedelta(days=int(p_age)) if p_age else None}
        self.http = Http(s["user_agent"], float(s.get("request_delay_seconds", 2)), int(s.get("timeout_seconds", 30)))
        self.job_rules = cfg["jobs"].get("relevance") or {}
        self.plantation_rules = cfg["plantations"].get("relevance") or {}

    @staticmethod
    def country_name(code: str) -> str | None:
        return COUNTRY_CODES.get((code or "").upper())


def due(src: dict, prev: dict | None, now) -> bool:
    gap = float(src.get("min_hours_between_runs", 0))
    if not gap or not prev or not prev.get("last_ok"):
        return True
    last = parse_iso(prev["last_ok"])
    return not last or now - last >= timedelta(hours=gap - 0.5)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--kind", choices=["jobs", "plantations"])
    ap.add_argument("--source", action="append", help="run only these source ids")
    ap.add_argument("--config", default=str(ROOT / "config" / "sources.yml"))
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    cfg = yaml.safe_load(Path(args.config).read_text())
    now = now_utc()
    ctx = Ctx(cfg, now)
    policy_keys = ("max_age_days", "expiry_basis", "missing_runs_before_removal")
    store = Store(ROOT, {k: {x: cfg[k][x] for x in policy_keys if x in cfg[k]} for k in ("jobs", "plantations")})
    status_path = ROOT / "data" / "status.json"
    status = json.loads(status_path.read_text()) if status_path.exists() else {"sources": {}, "runs": []}
    run_log = {"at": iso(now), "results": {}}
    attempted = failed = 0

    for kind in ("jobs", "plantations"):
        if args.kind and kind != args.kind:
            continue
        results: dict[str, list[dict]] = {}
        for src in cfg[kind]["sources"]:
            sid = src["id"]
            src.setdefault("name", sid)
            src["kind"] = kind
            prev = status["sources"].get(sid, {})
            if args.source and sid not in args.source:
                continue
            if src.get("requires_env") and not os.environ.get(src["requires_env"]):
                src["enabled"] = False
                src["note"] = f"Add the repository secret {src['requires_env']} to switch this source on"
            if not src.get("enabled", True):
                status["sources"][sid] = {**prev, "kind": kind, "name": src["name"], "status": "disabled",
                                          "message": src.get("note", "")}
                continue
            if not args.source and not due(src, prev, now):
                continue
            networked = src["type"] != "manual_csv"
            attempted += networked
            entry = {"kind": kind, "name": src["name"], "last_run": iso(now)}
            try:
                items = FETCHERS[src["type"]](src, ctx)
                results[sid] = items
                entry.update(status="ok", count=len(items), message="", last_ok=iso(now))
                log.info("%-24s ok      %4d listings", sid, len(items))
            except Blocked as exc:
                failed += networked
                entry.update(status="blocked", count=0, message=str(exc)[:300], last_ok=prev.get("last_ok"))
                log.warning("%-24s BLOCKED %s", sid, exc)
            except requests.RequestException as exc:
                failed += networked
                entry.update(status="error", count=0, message=f"{type(exc).__name__}: {exc}"[:300],
                             last_ok=prev.get("last_ok"))
                log.error("%-24s NETWORK %s", sid, str(exc)[:200])
            except Exception as exc:          # noqa: BLE001 — isolate every source
                failed += networked
                entry.update(status="error", count=0, message=f"{type(exc).__name__}: {exc}"[:300],
                             last_ok=prev.get("last_ok"))
                log.error("%-24s ERROR   %s\n%s", sid, exc, traceback.format_exc(limit=3))
            status["sources"][sid] = entry
            run_log["results"][sid] = {"status": entry["status"], "count": entry["count"]}

        reg = store.merge(kind, results, now)
        if cfg[kind].get("verify"):
            vstats = verify.run(store, kind, reg, ctx.http, cfg[kind]["verify"], now)
            run_log[f"{kind}_verification"] = vstats
            log.info("%s live-checks: %s", kind, vstats)
        items = store.active(kind, reg, now)
        src_status = [{"id": s["id"], "name": s.get("name", s["id"]), **{k: status["sources"].get(s["id"], {}).get(k)
                       for k in ("status", "last_ok", "count")}} for s in cfg[kind]["sources"]]
        store.write(kind, items, src_status, now)
        run_log[f"{kind}_published"] = len(items)
        log.info("%s: %d listings published", kind, len(items))

    status["generated_at"] = iso(now)
    status["runs"] = ([run_log] + status.get("runs", []))[:40]
    status_path.write_text(json.dumps(status, indent=1, ensure_ascii=False))
    if attempted and failed == attempted:
        log.error("Every online source failed this run (existing listings were kept)")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
