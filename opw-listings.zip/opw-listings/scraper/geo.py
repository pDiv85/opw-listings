"""Location normalisation.

Rule from the brief: Malaysia and Indonesia are grouped by state/province (and district where known);
every other country is grouped by country only.
"""
from __future__ import annotations

import re

from .common import clean, fold

MY_STATES = {
    "Johor": ["johor", "johore"],
    "Kedah": ["kedah"],
    "Kelantan": ["kelantan"],
    "Melaka": ["melaka", "malacca"],
    "Negeri Sembilan": ["negeri sembilan", "n. sembilan", "n9", "negri sembilan"],
    "Pahang": ["pahang"],
    "Penang": ["pulau pinang", "penang", "p. pinang"],
    "Perak": ["perak"],
    "Perlis": ["perlis"],
    "Sabah": ["sabah"],
    "Sarawak": ["sarawak"],
    "Selangor": ["selangor"],
    "Terengganu": ["terengganu", "trengganu"],
    "Kuala Lumpur": ["kuala lumpur", "wilayah persekutuan kuala lumpur", "kl city"],
    "Putrajaya": ["putrajaya"],
    "Labuan": ["labuan"],
}

# Frequent towns that appear without a state in job/property cards.
MY_TOWN_STATE = {
    "shah alam": "Selangor", "subang": "Selangor", "petaling jaya": "Selangor", "klang": "Selangor",
    "port klang": "Selangor", "pulau indah": "Selangor", "banting": "Selangor", "kuala selangor": "Selangor",
    "tanjong karang": "Selangor", "sepang": "Selangor", "cyberjaya": "Selangor", "puchong": "Selangor",
    "johor bahru": "Johor", "kluang": "Johor", "segamat": "Johor", "batu pahat": "Johor", "muar": "Johor",
    "kota tinggi": "Johor", "pontian": "Johor", "kulai": "Johor", "pasir gudang": "Johor", "mersing": "Johor",
    "kota kinabalu": "Sabah", "sandakan": "Sabah", "tawau": "Sabah", "lahad datu": "Sabah",
    "kinabatangan": "Sabah", "keningau": "Sabah", "kunak": "Sabah", "semporna": "Sabah", "beluran": "Sabah",
    "kuching": "Sarawak", "miri": "Sarawak", "sibu": "Sarawak", "bintulu": "Sarawak", "mukah": "Sarawak",
    "ipoh": "Perak", "teluk intan": "Perak", "taiping": "Perak", "sitiawan": "Perak", "kuala kangsar": "Perak",
    "bagan datuk": "Perak", "manjung": "Perak", "kuantan": "Pahang", "temerloh": "Pahang", "jerantut": "Pahang",
    "rompin": "Pahang", "pekan": "Pahang", "maran": "Pahang", "bentong": "Pahang",
    "seremban": "Negeri Sembilan", "port dickson": "Negeri Sembilan", "jempol": "Negeri Sembilan",
    "kuala pilah": "Negeri Sembilan", "gemas": "Negeri Sembilan",
    "alor setar": "Kedah", "sungai petani": "Kedah", "kulim": "Kedah", "kota bharu": "Kelantan",
    "gua musang": "Kelantan", "kuala terengganu": "Terengganu", "dungun": "Terengganu", "kemaman": "Terengganu",
    "butterworth": "Penang", "bukit mertajam": "Penang", "george town": "Penang", "nibong tebal": "Penang",
    "alor gajah": "Melaka", "jasin": "Melaka", "kangar": "Perlis",
}

ID_PROVINCES = {
    "Aceh": ["aceh", "nanggroe aceh darussalam"],
    "Sumatera Utara": ["sumatera utara", "sumatra utara", "north sumatra", "north sumatera", "sumut"],
    "Sumatera Barat": ["sumatera barat", "sumatra barat", "west sumatra", "west sumatera", "sumbar"],
    "Sumatera Selatan": ["sumatera selatan", "sumatra selatan", "south sumatra", "south sumatera", "sumsel"],
    "Kepulauan Riau": ["kepulauan riau", "riau islands", "kepri"],
    "Riau": ["riau"],
    "Jambi": ["jambi"],
    "Kepulauan Bangka Belitung": ["bangka belitung", "bangka-belitung", "babel"],
    "Bengkulu": ["bengkulu"],
    "Lampung": ["lampung"],
    "DKI Jakarta": ["dki jakarta", "jakarta raya", "jakarta"],
    "Jawa Barat": ["jawa barat", "west java"],
    "Banten": ["banten"],
    "Jawa Tengah": ["jawa tengah", "central java"],
    "DI Yogyakarta": ["yogyakarta", "jogja"],
    "Jawa Timur": ["jawa timur", "east java"],
    "Bali": ["bali"],
    "Nusa Tenggara Barat": ["nusa tenggara barat", "west nusa tenggara", "ntb"],
    "Nusa Tenggara Timur": ["nusa tenggara timur", "east nusa tenggara", "ntt"],
    "Kalimantan Barat": ["kalimantan barat", "west kalimantan", "kalbar"],
    "Kalimantan Tengah": ["kalimantan tengah", "central kalimantan", "kalteng"],
    "Kalimantan Selatan": ["kalimantan selatan", "south kalimantan", "kalsel"],
    "Kalimantan Timur": ["kalimantan timur", "east kalimantan", "kaltim"],
    "Kalimantan Utara": ["kalimantan utara", "north kalimantan", "kaltara"],
    "Sulawesi Utara": ["sulawesi utara", "north sulawesi"],
    "Gorontalo": ["gorontalo"],
    "Sulawesi Tengah": ["sulawesi tengah", "central sulawesi"],
    "Sulawesi Barat": ["sulawesi barat", "west sulawesi"],
    "Sulawesi Selatan": ["sulawesi selatan", "south sulawesi"],
    "Sulawesi Tenggara": ["sulawesi tenggara", "southeast sulawesi"],
    "Maluku Utara": ["maluku utara", "north maluku"],
    "Maluku": ["maluku"],
    "Papua Barat Daya": ["papua barat daya", "southwest papua"],
    "Papua Barat": ["papua barat", "west papua"],
    "Papua Tengah": ["papua tengah", "central papua"],
    "Papua Pegunungan": ["papua pegunungan", "highland papua"],
    "Papua Selatan": ["papua selatan", "south papua"],
    "Papua": ["papua"],
}


def _alias_table(table: dict) -> list[tuple[str, str]]:
    pairs = [(alias, name) for name, aliases in table.items() for alias in aliases]
    return sorted(pairs, key=lambda p: -len(p[0]))     # longest alias first ("papua barat daya" > "papua")


_MY = _alias_table(MY_STATES)
_ID = _alias_table(ID_PROVINCES)


def _find(table, text: str) -> str | None:
    t = " " + re.sub(r"[^a-z0-9.]+", " ", fold(text)) + " "
    for alias, name in table:
        if f" {alias} " in t:
            return name
    return None


def _dedupe_parts(text: str) -> str:
    """'Dungun, Terengganu, Dungun, Terengganu' -> 'Dungun, Terengganu'"""
    out, seen = [], set()
    for part in (clean(p) for p in text.split(",")):
        if part and fold(part) not in seen:
            seen.add(fold(part))
            out.append(part)
    return ", ".join(out)


def normalise_location(country: str, *texts: str, hint: str = "") -> dict:
    """Return {'country', 'state', 'district', 'location'} following the brief's grouping rule.

    `hint` (usually the job title) wins when it names a state, e.g. "KTU PALM OIL MILL - SUMATERA BARAT"
    advertised from a Jakarta head office."""
    texts = [clean(t) for t in texts if clean(t)]
    location = _dedupe_parts(texts[0]) if texts else ""
    joined = " , ".join(texts)
    state, district = None, None
    hinted = None
    if hint and country in ("Malaysia", "Indonesia"):
        hinted = _find(_MY if country == "Malaysia" else _ID, hint)
    if hinted:
        state = hinted
        location = f"{hinted} (advertised from {location})" if location and fold(hinted) not in fold(location) else location
        return {"country": country, "state": state, "district": None, "location": location}
    if country == "Malaysia":
        state = _find(_MY, joined)
        if not state:
            f = fold(joined)
            state = next((st for town, st in sorted(MY_TOWN_STATE.items(), key=lambda kv: -len(kv[0]))
                          if town in f), None)
    elif country == "Indonesia":
        state = _find(_ID, joined)
    if country in ("Malaysia", "Indonesia"):
        # district = first comma-part that is not the state itself
        for part in re.split(r"[,/|]", location):
            p = clean(re.sub(r"\b(district|daerah|kabupaten|kab\.|kota)\b", "", part, flags=re.I))
            if p and (not state or fold(p) != fold(state)) and _find(_MY if country == "Malaysia" else _ID, p) is None:
                district = p
                break
        return {"country": country, "state": state or "Other / unspecified",
                "district": district, "location": location or state or country}
    return {"country": country, "state": country, "district": None, "location": location or country}
