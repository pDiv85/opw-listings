"""Computrabajo (Colombia, Peru, Guatemala, Honduras, Ecuador, Mexico, Costa Rica…).

Search pages are server-rendered: https://<cc>.computrabajo.com/trabajo-de-<slug>?p=<n>
Each offer is an <article class="box_offer">. Posting age is shown as 'Hace 5 días' / 'Hace 21 horas'.
"""
from __future__ import annotations

import re

import requests
from bs4 import BeautifulSoup

from ..common import clean, parse_salary, relative_to_date
from ..geo import normalise_location
from ..relevance import job_match


def fetch(src: dict, ctx) -> list[dict]:
    seen, out = set(), []
    for slug in src["keywords"]:
        for page in range(1, int(src.get("max_pages", 5)) + 1):
            url = f"https://{src['host']}/trabajo-de-{slug}" + (f"?p={page}" if page > 1 else "")
            try:
                html = ctx.http.get(url)
            except requests.HTTPError as exc:
                if exc.response is not None and exc.response.status_code == 404:
                    break          # this keyword slug has no results page on this country site
                raise
            items, too_old = parse_page(html, src, ctx)
            fresh = [i for i in items if i["id"] not in seen]
            for i in fresh:
                seen.add(i["id"])
            out.extend(fresh)
            if not items or too_old or 'title="Siguiente"' not in html:
                break
    return out


def parse_page(html: str, src: dict, ctx) -> tuple[list[dict], bool]:
    soup = BeautifulSoup(html, "lxml")
    items, ages = [], []
    for art in soup.select("article.box_offer"):
        a = art.select_one("h2 a")
        if not a:
            continue
        oid = art.get("data-id") or a["href"].rsplit("-", 1)[-1].split("#")[0]
        title = clean(a.get_text())
        comp_p = art.select_one("p.dFlex")
        company = clean(comp_p.get_text()) if comp_p else ""
        loc_el = art.select_one("p.fs16 span.mr10")
        location = clean(loc_el.get_text()) if loc_el else ""
        sal_el = art.select_one(".i_salary")
        salary = clean(sal_el.parent.get_text()) if sal_el else ""
        age_el = art.select_one("p.fc_aux")
        age_txt = clean(age_el.get_text()) if age_el else ""
        posted = relative_to_date(age_txt, ctx.now)
        if posted:
            ages.append(posted)
        match = job_match(ctx.job_rules, title, company, "", trust_search=src.get("trust_search", True))
        if not match:
            continue
        href = a["href"].split("#")[0]
        if href.startswith("/"):
            href = f"https://{src['host']}{href}"
        sal = parse_salary(salary, src["country"])
        if sal["salary_text"] and "(" in sal["salary_text"]:
            sal["salary_text"] = re.sub(r"\s*\((Mensual|Diario|Por hora|Anual)\)", r" (\1)", sal["salary_text"])
        items.append({
            "id": f"computrabajo:{oid}",
            "source": src["id"],
            "source_name": src["name"],
            "url": href,
            "title": title,
            "company": company or "Confidential",
            **normalise_location(src["country"], location),
            **sal,
            "employment_type": None,
            "category": None,
            "summary": None,
            "source_date": posted,
            "date_basis": "posted (relative)",
            "match": match,
        })
    too_old = bool(ages) and max(ages) < ctx.cutoffs["jobs"]
    return items, too_old
