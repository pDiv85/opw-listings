"""JobStreet Malaysia / Indonesia and JobsDB Thailand (all run on SEEK's search API).

The public search API pages beyond page 1 without a sign-in, which is what the earlier browser-based
runs could not do. Results are sorted newest first and limited to the last `daterange` days.
"""
from __future__ import annotations

from ..common import clean, parse_iso, parse_salary
from ..geo import normalise_location
from ..relevance import job_match


def fetch(src: dict, ctx) -> list[dict]:
    host = src["host"]
    url = f"https://{host}/api/jobsearch/v5/search"
    seen, out = set(), []
    for kw in src["keywords"]:
        for page in range(1, int(src.get("max_pages", 5)) + 1):
            params = {
                "siteKey": src["site_key"], "sourcesystem": "houston", "keywords": kw,
                "page": page, "pageSize": int(src.get("page_size", 100)), "locale": src.get("locale", "en-MY"),
                "daterange": ctx.window_days + 1, "sortmode": "ListedDate",
            }
            data = ctx.http.get(url, params=params, expect_json=True)
            rows = data.get("data") or []
            for d in rows:
                jid = str(d.get("id"))
                if jid in seen:
                    continue
                seen.add(jid)
                item = parse_item(d, src, ctx)
                if item:
                    out.append(item)
            if len(rows) < params["pageSize"]:
                break
    return out


def parse_item(d: dict, src: dict, ctx) -> dict | None:
    title = clean(d.get("title"))
    company = clean(d.get("companyName") or (d.get("advertiser") or {}).get("description"))
    teaser = clean(d.get("teaser"))
    match = job_match(ctx.job_rules, title, company, teaser, trust_search=src.get("trust_search", False))
    if not match:
        return None
    locs = d.get("locations") or [{}]
    loc = locs[0]
    hier = [h.get("contextualName", "") for h in loc.get("seoHierarchy") or []]
    country = src["country"]
    if loc.get("countryCode") and loc.get("countryCode") != src.get("country_code", loc.get("countryCode")):
        country = ctx.country_name(loc["countryCode"]) or country     # e.g. PNG roles advertised in MY
    geo = normalise_location(country, loc.get("label", ""), *reversed(hier), hint=title)
    posted = parse_iso(d.get("listingDate"))
    return {
        "id": f"jobstreet:{d.get('id')}",
        "source": src["id"],
        "source_name": src["name"],
        "url": f"https://{src['host']}/job/{d.get('id')}",
        "title": title,
        "company": company if company.lower() not in ("private advertiser", "pengiklan anonim") else "Confidential",
        **geo,
        **parse_salary(d.get("salaryLabel") or "", country),
        "employment_type": ", ".join(d.get("workTypes") or []) or None,
        "category": ((d.get("classifications") or [{}])[0].get("classification") or {}).get("description"),
        "summary": teaser[:220] or None,
        "source_date": posted,
        "date_basis": "posted",
        "match": match,
    }
