"""Mudah.my — land for sale / rent matching palm keywords.

Cards are server-rendered as <a data-type="adlist_ad" data-listid="…"> (price, title, location, area,
tenure) plus a sibling <a data-type="ads"> carrying 'Listed 5 days ago by …'. Page n uses ?o=n.
"""
from __future__ import annotations

import re

from bs4 import BeautifulSoup

from ..common import clean, parse_amount, parse_area_acres, relative_to_date
from ..geo import normalise_location
from ..relevance import plantation_match


PAGE_SIZE = 40
SOLD_IN_TITLE = re.compile(r"\b(sold|terjual|sudah dijual|telah dijual)\b", re.I)


def fetch(src: dict, ctx) -> list[dict]:
    """Pages through every result; `_full_sweep` marks whether the last page was reached."""
    seen, out, complete = set(), [], True
    cutoff = ctx.cutoffs.get(src.get("kind", "plantations"))
    for kw in src["keywords"]:
        max_pages = int(src.get("max_pages", 25))
        for page in range(1, max_pages + 1):
            params = {"q": kw}
            if page > 1:
                params["o"] = page
            html = ctx.http.get(src["base_url"], params=params)
            items, n_cards = parse_page(html, src, ctx)
            fresh = [i for i in items if i["id"] not in seen]
            for i in fresh:
                seen.add(i["id"])
            out.extend(fresh)
            dates = [i["source_date"] for i in items if i.get("source_date")]
            if n_cards < PAGE_SIZE:
                break                       # last page reached
            if cutoff and dates and max(dates) < cutoff:
                complete = False
                break
            if page == max_pages:
                complete = False
    for i in out:
        i["_full_sweep"] = complete
    return out


def parse_page(html: str, src: dict, ctx) -> list[dict]:
    soup = BeautifulSoup(html, "lxml")
    cards: dict[str, dict] = {}
    all_ids = {a["data-listid"] for a in soup.select('a[data-listid][data-type="adlist_ad"]')}
    for a in soup.select('a[data-listid][data-type="adlist_ad"]'):
        parts = [clean(t) for t in a.stripped_strings]
        if not parts or not any(p.startswith("RM") for p in parts):
            continue
        cards.setdefault(a["data-listid"], {"href": a.get("href"), "parts": parts})
    for a in soup.select('a[data-listid][data-type="ads"]'):
        lid = a["data-listid"]
        if lid in cards:
            cards[lid]["meta"] = clean(" ".join(a.stripped_strings))
    items = []
    for lid, c in cards.items():
        item = parse_card(lid, c, src, ctx)
        if item:
            items.append(item)
    return items, len(all_ids)


def parse_card(lid: str, c: dict, src: dict, ctx) -> dict | None:
    parts = c["parts"]
    price_txt = next((p for p in parts if p.startswith("RM")), "")
    rest = [p for p in parts if p != price_txt]
    title = rest[0] if rest else ""
    area_txt = next((p for p in rest[1:] if re.search(r"acre|ekar|sq\.?\s?ft|hectare", p, re.I)), "")
    tenure = next((p for p in rest if p.lower() in ("freehold", "leasehold", "malay reserved", "bumi lot")), None)
    location = next((p for p in rest[1:] if "," in p and p not in (area_txt, tenure)), "")
    if SOLD_IN_TITLE.search(title):
        return {"id": f"mudah:{lid}", "inactive": "sold"}
    match = plantation_match(ctx.plantation_rules, title)
    if not match:
        return None
    meta = c.get("meta", "")
    posted = relative_to_date(meta, ctx.now)
    # Registered agents (REN/REA number shown) are named; private sellers are not, to keep personal data out.
    lister = None
    m = re.search(r"\bby\s*(.+)$", meta)
    if m:
        who = m.group(1)
        if re.search(r"\bre[an]\s*\d+", who, re.I):
            lister = clean(re.sub(r"\bre[an]\s*\d+\b", "", who, flags=re.I)) or "Registered agent"
        elif re.search(r"agent", who, re.I):
            lister = "Property agent"
        else:
            lister = "Private seller"
    price = parse_amount(price_txt)
    deal = src.get("deal", "sale")
    if re.search(r"/(mo|month|bulan)|per month|sebulan", price_txt, re.I):
        deal = "lease"
    return {
        "id": f"mudah:{lid}",
        "source": src["id"],
        "source_name": src["name"],
        "url": c["href"],
        "title": title,
        "deal": deal,
        **normalise_location("Malaysia", location),
        "price": price,
        "currency": "MYR",
        "price_text": price_txt or None,
        "price_basis": None,
        "area_acres": parse_area_acres(area_txt) or parse_area_acres(title),
        "tenure": tenure,
        "property_type": "Land",
        "agent": lister,
        "agent_licence": None,
        "image": None,
        "source_date": posted,
        "date_basis": "posted (relative)",
        **match,
    }
