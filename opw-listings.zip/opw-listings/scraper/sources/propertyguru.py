"""PropertyGuru Malaysia — agricultural land for sale / rent matching palm keywords.

Listing data is embedded in the page as JSON (<script id="__NEXT_DATA__">, path
props.pageProps.pageData.data.listingsData). Page n lives at /agricultural-land-for-sale/<n>.
Note: 'postedOn' is the agent's latest refresh date, not necessarily the first listing date — the
store keeps the earliest date it has ever seen for a listing.
"""
from __future__ import annotations

import json
import re
from datetime import datetime

from ..common import UTC, clean, fold, parse_area_acres
from ..geo import normalise_location
from ..relevance import plantation_match

TENURE = {"F": "Freehold", "L": "Leasehold", "M": "Malay reserve", "N": "Native land", "B": "Bumi lot"}


def fetch(src: dict, ctx) -> list[dict]:
    """Pages through every result (plantations have no age limit), so a listing missing from a complete
    sweep is evidence it was withdrawn. `_full_sweep` tells the store whether the sweep was complete."""
    seen, out, complete = set(), [], True
    cutoff = ctx.cutoffs.get(src.get("kind", "plantations"))
    for kw in src["keywords"]:
        max_pages = int(src.get("max_pages", 60))
        for page in range(1, max_pages + 1):
            base = src["base_url"].rstrip("/") + (f"/{page}" if page > 1 else "")
            html = ctx.http.get(base, params={"freetext": kw, "sort": "date", "order": "desc"})
            listings, total_pages = parse_page(html)
            page_items = []
            for ld in listings:
                item = parse_item(ld, src, ctx)
                if item and item["id"] not in seen:
                    seen.add(item["id"])
                    page_items.append(item)
            out.extend(page_items)
            dates = [i["source_date"] for i in page_items if i.get("source_date")]
            if not listings or page >= total_pages:
                break
            if cutoff and dates and max(dates) < cutoff:
                complete = False
                break
            if page == max_pages:
                complete = False          # more pages exist than we were allowed to read
    for i in out:
        i["_full_sweep"] = complete
    return out


def parse_page(html: str) -> tuple[list[dict], int]:
    m = re.search(r'<script id="__NEXT_DATA__"[^>]*>(.*?)</script>', html, re.S)
    if not m:
        return [], 0
    data = json.loads(m.group(1))["props"]["pageProps"]["pageData"]["data"]
    rows = [x.get("listingData") or {} for x in data.get("listingsData") or []]
    pages = int((data.get("paginationData") or {}).get("totalPages") or 1)
    return rows, pages


SOLD_IN_TITLE = re.compile(r"\b(sold|sold out|terjual|sudah dijual|telah dijual|vendido|vendue)\b", re.I)


def parse_item(l: dict, src: dict, ctx) -> dict | None:
    if not l.get("id"):
        return None
    lid = f"propertyguru:{l['id']}"
    title = clean(l.get("localizedTitle"))
    if l.get("statusCode") not in (None, "ACT"):
        return {"id": lid, "inactive": f"marked {l.get('statusCode')} (not active) on PropertyGuru"}
    if SOLD_IN_TITLE.search(title) or SOLD_IN_TITLE.search(clean(l.get("availabilityInfo"))):
        return {"id": lid, "inactive": "sold"}
    feats = " | ".join(clean(f.get("text")) for f in l.get("listingFeatures") or [] if isinstance(f, dict))
    unit_type = next((clean(f.get("text")) for f in l.get("listingFeatures") or []
                      if isinstance(f, dict) and f.get("dataAutomationId", "").endswith("unit-type")), None)
    if unit_type and "agricultural" not in unit_type.lower() and "land" not in unit_type.lower():
        return None
    match = plantation_match(ctx.plantation_rules, title, feats)
    acres = parse_area_acres((l.get("area") or {}).get("localeStringValue", "") or feats)
    if not match:
        return None
    add = l.get("additionalData") or {}
    geo = normalise_location("Malaysia", ", ".join(p for p in (add.get("districtText"), add.get("regionText")) if p),
                             l.get("fullAddress", ""))
    if add.get("districtText"):
        geo["district"] = clean(add["districtText"])
    geo["location"] = geo["location"] or clean(l.get("fullAddress"))
    if acres and (not title or fold(title) in fold(l.get("fullAddress", ""))):
        # agents often title the ad with just the town name
        title = f"Agricultural land, {acres:,.4g} acres — {title or geo['district'] or geo['state']}"
    price = l.get("price") or {}
    posted = None
    if (l.get("postedOn") or {}).get("unix"):
        posted = datetime.fromtimestamp(int(l["postedOn"]["unix"]), UTC).replace(microsecond=0)
    agent = l.get("agent") or {}
    return {
        "id": lid,
        "source": src["id"],
        "source_name": src["name"],
        "url": l.get("url"),
        "title": title or f"Agricultural land, {geo['location']}",
        "deal": src.get("deal", "sale"),
        **geo,
        "price": price.get("value"),
        "currency": price.get("currency") or "MYR",
        "price_text": clean(price.get("pretty")) or None,
        "price_basis": clean((price.get("type") or {}).get("text")) or None,
        "area_acres": acres,
        "tenure": TENURE.get(add.get("tenure"), add.get("tenure")),
        "property_type": unit_type,
        "agent": clean(agent.get("name")) or None,
        "agent_licence": clean(agent.get("license")) or None,
        "image": l.get("thumbnail"),
        "source_date": posted,
        "date_basis": "posted or refreshed",
        **match,
    }
