from . import computrabajo, jsearch, manual_csv, mudah, propertyguru, seek

FETCHERS = {
    "seek": seek.fetch,
    "computrabajo": computrabajo.fetch,
    "jsearch": jsearch.fetch,
    "propertyguru": propertyguru.fetch,
    "mudah": mudah.fetch,
    "manual_csv": manual_csv.fetch,
}
