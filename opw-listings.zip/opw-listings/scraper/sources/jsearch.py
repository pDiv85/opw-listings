"""Optional: JSearch API (RapidAPI), which indexes Google for Jobs — i.e. LinkedIn, Indeed, Glassdoor,
company career pages and national boards — through a licensed API instead of scraping those sites.

This is the clean way to cover Indeed/LinkedIn (which block scrapers and require sign-in) and the
countries without a scrapable local board (Nigeria, Ghana, PNG, India, Sri Lanka, Côte d'Ivoire…).
Enabled automatically when the repository secret JSEARCH_API_KEY is set. Check field names against
your plan's documentation on first use: the run log reports a clear error if the response changes.
"""
from __future__ import annotations

import os

from ..common import Blocked, clean, parse_iso, parse_salary
from ..geo import normalise_location
from ..relevance import job_match

ENDPOINT = "https://jsearch.p.rapidapi.com/search"


def fetch(src: dict, ctx) -> list[dict]:
    key = os.environ.get(src.get("api_key_env", "JSEARCH_API_KEY"))
    if not key:
        raise Blocked("No API key set (repository secret JSEARCH_API_KEY) — source skipped")
    headers = {"X-RapidAPI-Key": key, "X-RapidAPI-Host": "jsearch.p.rapidapi.com"}
    out, seen = [], set()
    for q in src["queries"]:
        params = {"query": q["query"], "page": 1, "num_pages": int(src.get("num_pages", 1)),
                  "date_posted": "month", "country": q["country_code"].lower()}
        data = ctx.http.get(ENDPOINT, params=params, headers=headers, expect_json=True)
        if data.get("status") not in (None, "OK"):
            raise RuntimeError(f"JSearch error: {str(data)[:200]}")
        for d in data.get("data") or []:
            jid = d.get("job_id")
            if not jid or jid in seen:
                continue
            seen.add(jid)
            item = parse_item(d, q, src, ctx)
            if item:
                out.append(item)
    return out


def parse_item(d: dict, q: dict, src: dict, ctx) -> dict | None:
    title = clean(d.get("job_title"))
    company = clean(d.get("employer_name"))
    desc = clean(d.get("job_description"))[:600]
    match = job_match(ctx.job_rules, title, company, desc)
    if not match:
        return None
    country = q["country"]
    sal_text = ""
    if d.get("job_min_salary") or d.get("job_max_salary"):
        cur = d.get("job_salary_currency") or ""
        lo, hi = d.get("job_min_salary"), d.get("job_max_salary")
        sal_text = f"{cur} {lo:,.0f}" + (f" – {cur} {hi:,.0f}" if hi and hi != lo else "") if lo else f"{cur} {hi:,.0f}"
        if d.get("job_salary_period"):
            sal_text += f" per {str(d['job_salary_period']).lower()}"
    publisher = clean(d.get("job_publisher")) or "Google Jobs"
    return {
        "id": f"jsearch:{d['job_id']}",
        "source": src["id"],
        "source_name": f"{publisher} (via JSearch)",
        "url": d.get("job_apply_link") or d.get("job_google_link"),
        "title": title,
        "company": company or "Confidential",
        **normalise_location(country, ", ".join(p for p in (d.get("job_city"), d.get("job_state")) if p)),
        **parse_salary(sal_text, country),
        "employment_type": clean(d.get("job_employment_type")) or None,
        "category": None,
        "summary": desc[:220] or None,
        "source_date": parse_iso(d.get("job_posted_at_datetime_utc")),
        "date_basis": "posted",
        "match": match,
    }
