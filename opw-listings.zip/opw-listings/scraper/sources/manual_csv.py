"""Hand-curated listings: manual/jobs.csv and manual/plantations.csv.

For leads that no scraper can reach reliably (SMERGERS, DealStream, Facebook groups, broker emails,
employer notices). Add a row, commit, and it appears on the site within the next run, subject to the
same 30-day window. Columns are the same as the JSON fields; see manual/README.md.
"""
from __future__ import annotations

import csv
from pathlib import Path

from ..common import clean, parse_amount, parse_area_acres, parse_iso, parse_salary, slug_key
from ..geo import normalise_location


def fetch(src: dict, ctx) -> list[dict]:
    path = Path(ctx.root) / src["path"]
    if not path.exists():
        return []
    out = []
    with path.open(newline="", encoding="utf-8-sig") as fh:
        for row in csv.DictReader(fh):
            row = {k.strip(): clean(v) for k, v in row.items() if k}
            if not row.get("url") or not row.get("title"):
                continue
            status = (row.get("status") or "").lower()
            if status in ("sold", "withdrawn", "expired", "leased", "closed", "filled"):
                out.append({"id": f"manual:{slug_key(row['url'])}", "inactive": status})
                continue
            posted = parse_iso(row.get("listed_date"))
            geo = normalise_location(row.get("country") or "Malaysia", row.get("location", ""), row.get("state", ""))
            if row.get("district"):
                geo["district"] = row["district"]
            base = {
                "id": f"manual:{slug_key(row['url'])}",
                "source": src["id"],
                "source_name": row.get("source_name") or "OPW research desk",
                "url": row["url"],
                "title": row["title"],
                **geo,
                "source_date": posted,
                "date_basis": "posted" if posted else "first seen",
            }
            if src["kind"] == "jobs":
                base.update({
                    "company": row.get("company") or "Confidential",
                    **parse_salary(row.get("salary", ""), geo["country"]),
                    "employment_type": row.get("employment_type") or None,
                    "category": row.get("category") or None,
                    "summary": row.get("summary") or None,
                    "match": "manual",
                })
            else:
                base.update({
                    "deal": (row.get("deal") or "sale").lower(),
                    "price": parse_amount(row["price"]) if row.get("price") else None,
                    "currency": row.get("currency") or None,
                    "price_text": row.get("price") or None,
                    "price_basis": row.get("price_basis") or None,
                    "area_acres": parse_area_acres(row.get("area", "")),
                    "tenure": row.get("tenure") or None,
                    "property_type": row.get("property_type") or "Plantation",
                    "agent": row.get("agent") or None,
                    "agent_licence": None,
                    "image": None,
                    "palm_signal": "manual",
                })
            out.append(base)
    return out
