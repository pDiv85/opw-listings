"""Merge each run into a persistent registry, apply each section's removal rules, de-duplicate
cross-posted listings and write the files the website reads.

Removal rules (per section, from config/sources.yml):
  jobs        - shown for `max_age_days` (30) from the original posting date, and removed earlier if the
                advert disappears from its site for `missing_runs_before_removal` runs in a row.
  plantations - no age limit. Removed only on evidence: marked sold/inactive by the site, the advert page
                is gone (see scraper/verify.py), or it has been absent from a full sweep of the site's
                search for `missing_runs_before_removal` runs and its page could not be checked.
"""
from __future__ import annotations

import csv
import json
from datetime import timedelta
from pathlib import Path

from .common import iso, now_utc, parse_iso, slug_key

KEEP_REGISTRY_DAYS = 120          # history kept after a listing was last seen live

JOB_FIELDS = ["id", "title", "company", "country", "state", "district", "location", "salary_text",
              "salary_min", "salary_max", "salary_currency", "salary_period", "employment_type", "category",
              "summary", "source", "source_name", "url", "listed_date", "first_seen", "last_checked",
              "date_basis", "match", "also_listed"]
PLANTATION_FIELDS = ["id", "title", "deal", "country", "state", "district", "location", "price", "currency",
                     "price_text", "price_basis", "area_acres", "area_ha", "price_per_acre", "tenure",
                     "property_type", "agent", "agent_licence", "image", "source", "source_name", "url",
                     "listed_date", "first_seen", "last_checked", "date_basis", "palm_signal", "also_listed"]

DEFAULT_POLICY = {
    "jobs": {"max_age_days": 30, "expiry_basis": "original", "missing_runs_before_removal": 4},
    "plantations": {"max_age_days": None, "expiry_basis": "original", "missing_runs_before_removal": 12},
}


def fingerprint(kind: str, it: dict) -> str:
    if kind == "jobs":
        return slug_key(it.get("title"), it.get("company"), it.get("country"), it.get("state"), it.get("district"))
    acres = it.get("area_acres")
    size = f"{round(acres, 1)}" if acres else it.get("title")
    price = f"{round((it.get('price') or 0) / 1000)}" if it.get("price") else ""
    return slug_key(it.get("deal"), it.get("country"), it.get("state"), it.get("district"), size, price)


def last_checked(rec: dict) -> str | None:
    dates = [d for d in (rec.get("last_seen"), rec.get("last_verified")) if d]
    return max(dates) if dates else None


class Store:
    def __init__(self, root: Path, policies: dict | None = None):
        self.root = Path(root)
        self.data = self.root / "data"
        self.state = self.data / "state"
        self.archive = self.data / "archive"
        for p in (self.data, self.state, self.archive):
            p.mkdir(parents=True, exist_ok=True)
        self.policy = {k: {**v, **((policies or {}).get(k) or {})} for k, v in DEFAULT_POLICY.items()}

    # ------------------------------------------------------------------ registry
    def _reg_path(self, kind):
        return self.state / f"registry-{kind}.json"

    def load(self, kind) -> dict:
        p = self._reg_path(kind)
        return json.loads(p.read_text()) if p.exists() else {}

    def save(self, kind, reg):
        keep_after = iso(now_utc() - timedelta(days=KEEP_REGISTRY_DAYS))
        reg = {k: v for k, v in reg.items() if v.get("status") == "active" or (last_checked(v) or keep_after) >= keep_after}
        self._reg_path(kind).write_text(json.dumps(reg, ensure_ascii=False, separators=(",", ":"), sort_keys=True))

    def remove(self, kind: str, rec: dict, reason: str, now) -> None:
        if rec.get("status") != "active":
            return
        rec["status"] = "removed"
        rec["removed_at"] = iso(now)
        rec["removed_reason"] = reason
        with (self.archive / f"{kind}-removed-{now:%Y-%m}.jsonl").open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False, sort_keys=True) + "\n")

    def merge(self, kind: str, results: dict[str, list[dict]], now=None) -> dict:
        """results: {source_id: [items]} for sources that ran successfully this time."""
        now = now or now_utc()
        pol = self.policy[kind]
        reg = self.load(kind)
        new_lines = []
        for source_id, items in results.items():
            seen = set()
            dates = [i["source_date"] for i in items if i.get("source_date")]
            covered_from = min(dates) if dates else None
            full_sweep = all(i.get("_full_sweep", False) for i in items) if items else False
            for it in items:
                if it.get("inactive"):                       # the site itself says sold / inactive
                    if it["id"] in reg:
                        self.remove(kind, reg[it["id"]], it["inactive"], now)
                    continue
                seen.add(it["id"])
                sd = iso(it.get("source_date"))
                prev = reg.get(it["id"])
                rec = {k: v for k, v in it.items() if k not in ("source_date", "_full_sweep")}
                rec["source_date"] = sd
                if prev:
                    rec["first_seen"] = prev["first_seen"]
                    earliest = [d for d in (prev.get("earliest_source_date"), sd) if d]
                    rec["earliest_source_date"] = min(earliest) if earliest else None
                    rec["last_verified"] = prev.get("last_verified")
                    rec["last_checked_at"] = prev.get("last_checked_at")
                else:
                    rec["first_seen"] = iso(now)
                    rec["earliest_source_date"] = sd
                    new_lines.append(rec)
                rec["last_seen"] = iso(now)
                rec["misses"] = 0
                rec["status"] = "active"
                reg[it["id"]] = rec
            # listings from this source missing from this run's results
            for rid, rec in reg.items():
                if rec.get("source") != source_id or rid in seen or rec.get("status") != "active":
                    continue
                sd = parse_iso(rec.get("source_date"))
                if covered_from and sd and sd < covered_from and not full_sweep:
                    continue   # older than what we paged through this run: not evidence of removal
                rec["misses"] = rec.get("misses", 0) + 1
                if rec["misses"] >= int(pol["missing_runs_before_removal"]):
                    self.remove(kind, rec, "no longer listed on the source site", now)
        self.save(kind, reg)
        if new_lines:
            with (self.archive / f"{kind}-{now:%Y-%m}.jsonl").open("a", encoding="utf-8") as fh:
                for rec in new_lines:
                    fh.write(json.dumps(rec, ensure_ascii=False, sort_keys=True) + "\n")
        return reg

    # ------------------------------------------------------------------ output
    def listed_date(self, kind: str, rec: dict) -> str | None:
        if self.policy[kind]["expiry_basis"] == "latest":
            return rec.get("source_date") or rec.get("first_seen")
        cands = [d for d in (rec.get("earliest_source_date"), rec.get("first_seen")) if d]
        return min(cands) if cands else None

    def active(self, kind: str, reg: dict, now=None) -> list[dict]:
        now = now or now_utc()
        max_age = self.policy[kind]["max_age_days"]
        cutoff = iso(now - timedelta(days=int(max_age))) if max_age else None
        fields = JOB_FIELDS if kind == "jobs" else PLANTATION_FIELDS
        rows = []
        for rec in reg.values():
            if rec.get("status") != "active":
                continue
            ld = self.listed_date(kind, rec)
            if not ld or (cutoff and ld < cutoff):
                continue
            r = dict(rec)
            r["listed_date"] = ld
            r["last_checked"] = last_checked(rec)
            if kind == "plantations":
                a = r.get("area_acres")
                r["area_ha"] = round(a / 2.4710538, 2) if a else None
                r["price_per_acre"] = round(r["price"] / a) if a and r.get("price") and r.get("deal") == "sale" else None
            rows.append(r)
        # cross-posting: keep the richest/earliest copy, list the others as alternates
        groups: dict[str, list[dict]] = {}
        for r in rows:
            groups.setdefault(fingerprint(kind, r), []).append(r)
        out = []
        for grp in groups.values():
            def score(x):
                rich = bool(x.get("salary_min") if kind == "jobs" else x.get("price"))
                return (not rich, x["listed_date"])
            grp.sort(key=score)
            primary = dict(grp[0])
            primary["also_listed"] = [{"source_name": g["source_name"], "url": g["url"]} for g in grp[1:]
                                      if g["url"] != primary["url"]] or None
            primary["listed_date"] = min(g["listed_date"] for g in grp)
            primary["last_checked"] = max(g["last_checked"] or "" for g in grp) or None
            out.append({k: primary.get(k) for k in fields})
        out.sort(key=lambda x: x["listed_date"], reverse=True)
        return out

    def write(self, kind: str, items: list[dict], source_status: list[dict], now=None):
        now = now or now_utc()
        payload = {"kind": kind, "generated_at": iso(now), "max_age_days": self.policy[kind]["max_age_days"],
                   "count": len(items), "sources": source_status, "items": items}
        (self.data / f"{kind}.json").write_text(json.dumps(payload, ensure_ascii=False, separators=(",", ":")))
        fields = JOB_FIELDS if kind == "jobs" else PLANTATION_FIELDS
        with (self.data / f"{kind}.csv").open("w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=fields, extrasaction="ignore")
            w.writeheader()
            for it in items:
                row = dict(it)
                row["also_listed"] = " | ".join(a["url"] for a in it.get("also_listed") or [])
                w.writerow(row)
