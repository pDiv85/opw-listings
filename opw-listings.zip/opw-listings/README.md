# OPW Listings: Plantation Jobs and Plantations for Sale / Lease

This repository refreshes oil palm job vacancies and plantation sale/lease listings **every 6 hours**
(02:17, 08:17, 14:17 and 20:17 Malaysia time). It publishes them as JSON for the Oil Palm World
subscriber pages.

**Removal rules**
- **Jobs** stay up for **30 days** from the original posting date. They come off sooner if the advert
  disappears from its site.
- **Plantations** have **no age limit**. They stay up for as long as the advert is live, and come off only
  on evidence that the land is **sold** or the advert has been **withdrawn**:
  - the site marks it sold or inactive;
  - its page returns "not found", redirects away, or says the ad has expired (two checks in a row must
    agree); or
  - it is missing from a complete sweep of the site for 3 days and its page cannot be checked.

```
GitHub Actions (cron, 4×/day)
   └─ python -m scraper.run
        ├─ jobs:        JobStreet MY · JobStreet ID · Computrabajo (CO, PE, GT, HN, EC, MX, CR)
        │               · Google Jobs via JSearch (optional) · manual/jobs.csv
        └─ plantations: PropertyGuru MY (sale + rent) · Mudah (sale + rent) · manual/plantations.csv
   └─ data/jobs.json, data/plantations.json (+ .csv copies, status.json, monthly archive)
        └─ commit → OPW WordPress page ([opw_listings] shortcode or Custom HTML block)
```

## How this differs from the earlier ChatGPT/Codex runs

| Earlier runs | This version |
|---|---|
| A chat agent clicked through sites each time someone typed “run the scraper” | Runs on a schedule with no one involved, and keeps a full run log |
| JobStreet stopped after page 1 (sign-in wall) | Reads JobStreet’s search API: every page, up to 100 per request, newest first (about 224 MY and 569 ID palm jobs in the last 30 days on 25 Nov 2026, against 128 in the sheet) |
| Duplicates removed by hand | Removed automatically. Cross-posted ads (same job or land on two sites or by two agents) are merged, with “Also advertised on …” links |
| Expired ads checked one by one | Each run sweeps every results page. A plantation missing from the sweep has its advert page opened and checked (up to 80 a run), and each removal is logged with its reason (sold / withdrawn) in `data/archive/plantations-removed-*.jsonl`. That log is useful market intelligence too |
| “Refreshed” agent ads looked new | The earliest date ever seen is kept. The two spreadsheets are loaded as history, so a plantation shows its true time on the market (e.g. “Listed 20 Oct 2026, 36 days on the market”), and a re-posted job doesn’t restart its 30 days |
| Rubber, durian and mall jobs crept in | Relevance filter (palm terms, palm companies, exclusion list) that you can tune in `config/sources.yml` |
| One blocked site could stall the run | Each source runs on its own. A failure keeps that source’s existing listings and is reported in the run summary |

## Setup (about 20 minutes, one-off)

1. **Create the repository.** On GitHub: New repository → `opw-listings` → **Private** (recommended, so
   only paying subscribers can reach the data) → upload every file in this folder, keeping the folder
   structure (including `.github/`).
2. **Allow the workflow to save data.** Go to Settings → Actions → General → *Workflow permissions* →
   **Read and write permissions** → Save.
3. **First run.** Go to Actions → *Refresh OPW listings* → **Run workflow**. After 5–15 minutes, open the run
   to see the summary table: how many listings each source returned, and which (if any) were blocked.
   From then on it runs by itself 4 times a day.
4. **Put it on the website**. Choose one:
   - **A. Subscriber-only (recommended, private repo).** Copy `wordpress/opw-listings-gate.php` and
     `web/opw-listings.html` into `wp-content/mu-plugins/` on the OPW server. Add the four `define(...)`
     lines shown at the top of the PHP file to `wp-config.php`. The token should be a GitHub
     *fine-grained* token for this repository only, with **Contents: Read-only**. Then put the shortcode
     `[opw_listings]` on a page. Signed-in subscribers see the listings. Everyone else sees a
     “Subscribe or sign in” box, and the data endpoint refuses them too. Hook the paywall plugin into the
     `opw_listings_can_view` filter (examples in the PHP header), and exclude this page from any page cache.
   - **B. Quick start (public repo).** Paste `web/opw-listings.html` into a Custom HTML block and replace
     `YOUR-GITHUB-ORG` in the two `*Url` lines with the GitHub account name. This is simpler, but
     anyone who finds the JSON link can read the data, so the paywall only hides the page.
5. **Optional: more countries and LinkedIn/Indeed coverage.** Sign up for the JSearch API on RapidAPI. Add the
   key as a repository secret named `JSEARCH_API_KEY` (Settings → Secrets and variables → Actions). The
   `jsearch` source then switches itself on and runs once a day across 13 countries, including Nigeria,
   Ghana, PNG, Côte d’Ivoire, India, Sri Lanka, Thailand and Cameroon. It reaches LinkedIn, Indeed and
   Glassdoor adverts through a licensed API, so it doesn’t scrape those sites, which block bots and
   require sign-in. Check the free tier’s monthly request allowance against 13 queries a day.

## Day-to-day

- **Add a listing by hand** (broker email, SMERGERS, a Facebook group, an employer notice): add a row to
  `manual/plantations.csv` or `manual/jobs.csv` on GitHub and commit. It appears after the next run.
  `listed_date` is `YYYY-MM-DD`. See `manual/README.md`.
- **Switch a source off, or change keywords or page depth:** edit `config/sources.yml`.
- **Check health:** see the Actions tab (each run has a summary table) or `data/status.json`. The website footer
  also shows which sources were live on the last run.
- **Excel copies** of what is live are in `data/jobs.csv` and `data/plantations.csv`.
- **History for analysis** (every listing the first time it was seen) is in `data/archive/*.jsonl`.

## Decisions worth confirming

- **What we republish.** Each listing shows facts (title, place, size, price, salary, date) and links to
  the original advert. Photos, full descriptions and phone numbers are not copied. Private sellers on
  Mudah are shown as “Private seller”. Only registered agents (REN/REA) are named.

## Known limits

- **Plantation live-checks need the site to answer.** If PropertyGuru or Mudah refuse page checks from
  GitHub’s servers, sold or withdrawn listings are only caught by the 3-day “missing from a complete
  sweep” rule. That is slower, but the scraper still never guesses. The run summary shows how many pages
  could not be checked.
- **Hand-added plantations** (`manual/plantations.csv`) stay up until you set their `status` column to
  `sold` or `withdrawn`, or delete the row.
- **Blocking.** JobsDB Thailand already returns HTTP 403 to automated requests, so it is off and Thailand
  comes via JSearch. PropertyGuru and Mudah may block GitHub’s cloud servers. The scraper never tries to
  get round a block: it marks the source “blocked” and keeps the last good listings. If a source stays
  blocked, run the workflow on an office machine instead. Register a self-hosted runner (Settings →
  Actions → Runners) and set the repository variable `RUNNER` to `self-hosted`.
- **Site terms.** JobStreet, PropertyGuru and Mudah do not offer public data feeds, and their terms
  restrict automated collection and commercial reuse. Republishing their listings behind a paywall
  carries risk. A partnership or feed agreement with the larger portals is the robust route. Get a legal
  view before launch.
- **GitHub schedules** can start a few minutes late at busy times. GitHub may pause scheduled workflows in
  a repository with no activity for 60 days. The data commits normally count as activity, but check the
  Actions tab if updates stop.
- **Countries with thin online markets** (Sierra Leone, Congo, Nicaragua and others) will rely mostly on
  JSearch and the manual CSV.

## Local run (for TechSpark / developers)

```bash
pip install -r requirements.txt pytest
python -m pytest -q tests          # offline tests against saved copies of live pages
python -m scraper.run              # full run; --kind jobs|plantations, --source jobstreet_my
python -m scraper.summary          # status table
python -m seed.import_excel --jobs old_jobs.xlsx --plantations old_plantations.xlsm   # history import (already done)
```
