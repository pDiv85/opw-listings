"""One-off: load the earlier hand-compiled workbooks as *history*.

    python -m seed.import_excel --jobs Plantation_Jobs_scraper.xlsx --plantations Global_Oil_Palm_..._Directory.xlsm

Nothing is published from here. It records that each listing URL was already known on or before the
date it was collected. When the scraper finds that advert again it keeps the original date: a re-posted
job does not restart its 30 days, and a plantation shows its true time on the market.
"""
from __future__ import annotations

import argparse
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

import openpyxl

from scraper.common import iso, now_utc, relative_to_date
from scraper.store import Store

ROOT = Path(__file__).resolve().parent.parent
UTC = timezone.utc

PATTERNS = [
    (r"jobstreet\.com/(?:[a-z-]+/)?job/(\d+)", "jobstreet"),
    (r"computrabajo\.com/ofertas-de-trabajo/.*-([0-9A-F]{32})", "computrabajo"),
    (r"propertyguru\.com\.my/property-listing/.*-(\d{6,})", "propertyguru"),
    (r"mudah\.my/.*-(\d{6,})\.htm", "mudah"),
]


def listing_id(url: str) -> str | None:
    for pat, site in PATTERNS:
        m = re.search(pat, url or "", re.I)
        if m:
            return f"{site}:{m.group(1)}"
    return None


def as_dt(v) -> datetime | None:
    if isinstance(v, datetime):
        return v.replace(tzinfo=UTC) if v.tzinfo is None else v
    return None


def rows(path: Path, sheet: str):
    ws = openpyxl.load_workbook(path, read_only=True, data_only=True)[sheet]
    it = ws.iter_rows(values_only=True)
    header = [str(h).strip() if h else "" for h in next(it)]
    for r in it:
        yield dict(zip(header, r))


def seed_jobs(path: Path, store: Store, now) -> int:
    reg = store.load("jobs")
    n = 0
    for r in rows(path, "Jobs Data"):
        lid = listing_id(r.get("Job URL") or "")
        if not lid or lid in reg:
            continue
        scraped = as_dt(r.get("Scraped At")) or now
        posted = as_dt(r.get("Posted Date"))
        if not posted and isinstance(r.get("Posted Date"), str):
            m = re.search(r"checked (\d{1,2} \w{3} \d{4})", r["Posted Date"])
            ref = datetime.strptime(m.group(1), "%d %b %Y").replace(tzinfo=UTC) if m else scraped
            posted = relative_to_date(r["Posted Date"].split("(")[0], ref)
        first = min(d for d in (posted, scraped) if d)
        reg[lid] = {"id": lid, "status": "seed", "source": "seed", "title": r.get("Job Title"),
                    "url": r.get("Job URL"), "first_seen": iso(first), "earliest_source_date": iso(first),
                    "last_seen": iso(now)}
        n += 1
    store.save("jobs", reg)
    return n


def seed_plantations(path: Path, store: Store, now, collected_by: datetime) -> int:
    reg = store.load("plantations")
    n = 0
    for sheet in ("Recent Plantations", "Plantation Sources"):
        for r in rows(path, sheet):
            url = r.get("Source URL") or r.get("URL") or ""
            lid = listing_id(url)
            if not lid or lid in reg:
                continue
            posted = as_dt(r.get("Date of post")) or as_dt(r.get("Listing / refresh date"))
            first = min(d for d in (posted, collected_by) if d)
            reg[lid] = {"id": lid, "status": "seed", "source": "seed", "title": r.get("Plantation / listing"),
                        "url": url, "first_seen": iso(first), "earliest_source_date": iso(first),
                        "last_seen": iso(now)}
            n += 1
    store.save("plantations", reg)
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=Path)
    ap.add_argument("--plantations", type=Path)
    ap.add_argument("--collected-by", default="2026-10-20",
                    help="date the plantation workbook was last refreshed (records were seen on or before this)")
    a = ap.parse_args()
    now = now_utc()
    store = Store(ROOT, {})
    if a.jobs:
        print("jobs history rows added:", seed_jobs(a.jobs, store, now))
    if a.plantations:
        cb = datetime.strptime(a.collected_by, "%Y-%m-%d").replace(tzinfo=UTC)
        print("plantation history rows added:", seed_plantations(a.plantations, store, now, cb))


if __name__ == "__main__":
    main()
