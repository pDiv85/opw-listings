"""Builds web/preview-data.js from the saved live fixtures, through the real parsers and store,
so the HTML page can be previewed before the repository is live."""
import json
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from test_pipeline import NOW, SEEK_MY, Ctx                      # noqa: E402
from scraper.sources import computrabajo, mudah, propertyguru, seek  # noqa: E402
from scraper.store import Store                                  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
tmp = Path(tempfile.mkdtemp())
(tmp / "data" / "state").mkdir(parents=True)
for f in (ROOT / "data" / "state").glob("registry-*.json"):           # include spreadsheet history
    shutil.copy(f, tmp / "data" / "state" / f.name)
st = Store(tmp, {})
jobs = {
    "jobstreet_my": seek.fetch(SEEK_MY, Ctx({"my.jobstreet.com": "seek_my.json"})),
    "jobstreet_id": seek.fetch({**SEEK_MY, "id": "jobstreet_id", "name": "JobStreet Indonesia", "host": "id.jobstreet.com",
                                "country": "Indonesia", "country_code": "ID"}, Ctx({"id.jobstreet.com": "seek_id.json"})),
    "computrabajo_co": computrabajo.fetch({"id": "computrabajo_co", "name": "Computrabajo Colombia", "host": "co.computrabajo.com",
                                           "country": "Colombia", "keywords": ["palma-de-aceite"], "max_pages": 1, "trust_search": True},
                                          Ctx({"computrabajo": "computrabajo_co.html"})),
}
pl = {
    "propertyguru_my_sale": propertyguru.fetch({"id": "propertyguru_my_sale", "name": "PropertyGuru Malaysia", "base_url": "https://www.propertyguru.com.my/agricultural-land-for-sale",
                                                "deal": "sale", "keywords": ["oil palm"], "max_pages": 1}, Ctx({"propertyguru": "pg_sale.html"})),
    "mudah_my_sale": mudah.fetch({"id": "mudah_my_sale", "name": "Mudah.my", "base_url": "https://www.mudah.my/malaysia/land-for-sale",
                                  "deal": "sale", "keywords": ["sawit"], "max_pages": 1}, Ctx({"mudah.my": "mudah_sale.html"})),
}
out = {}
for kind, res in (("jobs", jobs), ("plantations", pl)):
    reg = st.merge(kind, res, NOW)
    items = st.active(kind, reg, NOW)
    srcs = [{"id": k, "name": v[0]["source_name"] if v else k, "status": "ok", "last_ok": "2026-11-25T07:00:00Z", "count": len(v)} for k, v in res.items()]
    out[kind] = {"kind": kind, "generated_at": "2026-11-25T07:00:00Z", "max_age_days": 30 if kind == "jobs" else None,
                 "count": len(items), "sources": srcs, "items": items}
    print(kind, len(items), "published from", sum(len(v) for v in res.values()), "parsed")
(ROOT / "web" / "preview-data.js").write_text("window.OPW_LISTINGS_DATA = " + json.dumps(out, ensure_ascii=False) + ";\n")
