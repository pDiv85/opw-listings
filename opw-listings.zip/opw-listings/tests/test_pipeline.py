"""Offline tests: parsers run against saved copies of live pages (25 Nov 2026)."""
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

from scraper.common import parse_amount, parse_area_acres, parse_salary, relative_to_date
from scraper.geo import normalise_location
from scraper.sources import computrabajo, mudah, propertyguru, seek
from scraper import verify
from scraper.common import Blocked
from scraper.store import Store

FIX = Path(__file__).parent / "fixtures"
NOW = datetime(2026, 11, 25, 7, 0, tzinfo=timezone.utc)


class FakeHttp:
    def __init__(self, routes):
        self.routes = routes

    def get(self, url, params=None, headers=None, expect_json=False):
        for key, fname in self.routes.items():
            if key in url and (params is None or params.get("page", 1) in (1, None)) and (params or {}).get("o") is None:
                text = (FIX / fname).read_text()
                return json.loads(text) if expect_json else text
        return {"data": []} if expect_json else "<html></html>"


class Ctx:
    def __init__(self, routes):
        self.http = FakeHttp(routes)
        self.now = NOW
        self.window_days = 30
        self.cutoff = NOW - timedelta(days=30)
        self.cutoffs = {"jobs": self.cutoff, "plantations": None}
        self.job_rules, self.plantation_rules = {}, {}
        self.root = Path(__file__).parent.parent

    @staticmethod
    def country_name(code):
        return {"PG": "Papua New Guinea"}.get(code)


SEEK_MY = {"id": "jobstreet_my", "name": "JobStreet Malaysia", "host": "my.jobstreet.com", "site_key": "MY-Main",
           "country": "Malaysia", "country_code": "MY", "keywords": ["palm oil"], "max_pages": 1}


def test_amounts_and_salary():
    assert parse_amount("RM 2,654,300") == 2654300
    assert parse_amount("Rp 12.000.000") == 12_000_000
    assert parse_amount("$ 8.000.000,00") == 8_000_000
    assert parse_amount("2.13 acre") == 2.13
    s = parse_salary("Rp 12.000.000 – Rp 18.000.000 per month", "Indonesia")
    assert (s["salary_min"], s["salary_max"], s["salary_currency"], s["salary_period"]) == (12e6, 18e6, "IDR", "month")
    s = parse_salary("$ 8.000.000,00 (Mensual)", "Colombia")
    assert s["salary_currency"] == "COP" and s["salary_min"] == 8e6 and s["salary_period"] == "month"
    assert parse_salary("", "Malaysia")["salary_text"] == "Not disclosed"


def test_area_and_dates():
    assert parse_area_acres("15.23 Acre(s)") == 15.23
    assert parse_area_acres("[KEBUN SAWIT] 2.144 Ekar, Kg Rahmat") == 2.144
    assert parse_area_acres("1,109 acre (land)") == 1109
    assert round(parse_area_acres("100 ha")) == 247
    assert round(parse_area_acres("92 manzanas")) == 159
    assert relative_to_date("Listed 5 days ago by", NOW) == NOW - timedelta(days=5)
    assert relative_to_date("Hace 21 horas", NOW) == NOW - timedelta(hours=21)
    assert relative_to_date("2 hari yang lalu", NOW) == NOW - timedelta(days=2)


def test_location_rules():
    assert normalise_location("Malaysia", "Shah Alam/Subang")["state"] == "Selangor"
    assert normalise_location("Malaysia", "Lahad Datu District, Sabah")["district"] == "Lahad Datu"
    assert normalise_location("Indonesia", "Katingan Hilir, Kalimantan Tengah")["state"] == "Kalimantan Tengah"
    assert normalise_location("Indonesia", "Jakarta Raya", hint="KTU PALM OIL MILL (POM) - SUMATERA BARAT")["state"] == "Sumatera Barat"
    assert normalise_location("Indonesia", "Jayapura, Papua Barat Daya")["state"] == "Papua Barat Daya"
    assert normalise_location("Peru", "Ucayali")["state"] == "Peru"


def test_seek_relevance():
    items = seek.fetch(SEEK_MY, Ctx({"my.jobstreet.com": "seek_my.json"}))
    titles = {i["title"] for i in items}
    for keep in ("Mill Engineer", "Estate Manager", "Field Conductor / Senior Field Conductor",
                 "Sustainability Officer (Based in Palm Oil Estate)", "Best Practice Engineer"):
        assert keep in titles
    for drop in ("Farm Crew", "Sales executive", "Plantation Field Supervisor", "Mandor (Rubber Plantation)",
                 "OPERATOR (MALAYSIA)", "Technical Sales Executive", "Trading Manager (Representative, Malaysia Office)"):
        assert drop not in titles
    mill = next(i for i in items if i["title"] == "Mill Engineer")
    assert mill["state"] == "Sabah" and mill["salary_min"] == 4000 and mill["url"].endswith("/job/96054233")


def test_seek_indonesia():
    src = {**SEEK_MY, "id": "jobstreet_id", "host": "id.jobstreet.com", "country": "Indonesia", "country_code": "ID"}
    items = seek.fetch(src, Ctx({"id.jobstreet.com": "seek_id.json"}))
    by = {i["url"].rsplit("/", 1)[-1]: i for i in items}
    assert by["96112955"]["state"] == "Sumatera Barat"
    assert by["96114256"]["company"] == "Confidential"
    assert "96109819" not in by     # warehouse job, no palm signal


def test_propertyguru():
    src = {"id": "propertyguru_my_sale", "name": "PropertyGuru Malaysia", "base_url": "https://www.propertyguru.com.my/agricultural-land-for-sale",
           "deal": "sale", "keywords": ["oil palm"], "max_pages": 1}
    items = propertyguru.fetch(src, Ctx({"propertyguru": "pg_sale.html"}))
    assert len(items) == 8
    paloh = next(i for i in items if "965" in i["title"])
    assert paloh["state"] == "Johor" and paloh["district"] == "Paloh" and paloh["area_acres"] == 965
    assert paloh["price"] == 120625000 and paloh["price_basis"] == "Negotiable" and paloh["tenure"] == "Freehold"
    solar = next(i for i in items if "1,109" in i["title"])
    assert solar["palm_signal"] == "search" and solar["area_acres"] == 1109


def test_mudah():
    src = {"id": "mudah_my_sale", "name": "Mudah.my", "base_url": "https://www.mudah.my/malaysia/land-for-sale",
           "deal": "sale", "keywords": ["sawit"], "max_pages": 1}
    items = mudah.fetch(src, Ctx({"mudah.my": "mudah_sale.html"}))
    assert len(items) == 9                      # durian orchard excluded
    k = next(i for i in items if i["url"].endswith("116376917.htm"))
    assert k["state"] == "Perak" and k["district"] == "Kuala Kangsar" and k["area_acres"] == 331.58
    assert k["price"] == 39789960 and k["agent"] == "Property agent"
    priv = next(i for i in items if i["url"].endswith("116379232.htm"))
    assert priv["agent"] == "Private seller" and priv["source_date"] == NOW - timedelta(hours=6)


def test_computrabajo():
    src = {"id": "computrabajo_co", "name": "Computrabajo Colombia", "host": "co.computrabajo.com",
           "country": "Colombia", "keywords": ["palma-de-aceite"], "max_pages": 1, "trust_search": True}
    items = computrabajo.fetch(src, Ctx({"computrabajo": "computrabajo_co.html"}))
    assert len(items) == 3
    d = items[0]
    assert d["state"] == "Colombia" and d["salary_currency"] == "COP" and d["url"].startswith("https://co.computrabajo.com/ofertas")
    assert items[2]["company"] == "Colinagro S.A"


def test_store_expiry_dedupe_and_removal(tmp_path):
    st = Store(tmp_path, {"jobs": {"missing_runs_before_removal": 2}})
    base = {"source": "s1", "source_name": "S1", "company": "Felda", "country": "Malaysia", "state": "Pahang",
            "district": None, "location": "Kuantan", "salary_text": "Not disclosed"}
    a = {**base, "id": "x:1", "title": "Estate Manager", "url": "u1", "source_date": NOW - timedelta(days=2)}
    old = {**base, "id": "x:2", "title": "Mill Manager", "url": "u2", "source_date": NOW - timedelta(days=40)}
    dup = {**base, "id": "x:3", "title": "Estate Manager", "url": "u3", "source_date": NOW - timedelta(days=1), "source": "s1"}
    reg = st.merge("jobs", {"s1": [a, old, dup]}, NOW)
    act = st.active("jobs", reg, NOW)
    assert [i["id"] for i in act] == ["x:1"] and act[0]["also_listed"][0]["url"] == "u3"
    # an agent "refreshes" x:1 so it looks new — the original date is kept
    reg = st.merge("jobs", {"s1": [{**a, "source_date": NOW}, dup]}, NOW + timedelta(hours=6))
    assert st.active("jobs", reg, NOW)[0]["listed_date"] == (NOW - timedelta(days=2)).strftime("%Y-%m-%dT%H:%M:%SZ")
    # x:1 disappears from the source for two runs -> removed
    for h in (12, 18):
        reg = st.merge("jobs", {"s1": [dup]}, NOW + timedelta(hours=h))
    assert [i["id"] for i in st.active("jobs", reg, NOW + timedelta(hours=18))] == ["x:3"]
    # a failed source (absent from results) leaves its listings alone
    reg = st.merge("jobs", {}, NOW + timedelta(hours=24))
    assert reg["x:3"]["status"] == "active"


PLOT = {"source": "mudah_my_sale", "source_name": "Mudah.my", "deal": "sale", "country": "Malaysia", "state": "Perak",
        "district": "Kuala Kangsar", "location": "Kuala Kangsar, Perak", "price": 39789960, "currency": "MYR",
        "area_acres": 331.58, "title": "Oil Palm Plantation for Sale"}


def test_plantations_have_no_age_limit_and_leave_only_on_evidence(tmp_path):
    st = Store(tmp_path, {})
    old = {**PLOT, "id": "mudah:1", "url": "https://www.mudah.my/oil-palm-plantation-for-sale-1000001.htm",
           "source_date": NOW - timedelta(days=200), "_full_sweep": True}
    sold = {**PLOT, "id": "mudah:2", "url": "https://www.mudah.my/x-1000002.htm", "area_acres": 50,
            "source_date": NOW - timedelta(days=3), "_full_sweep": True}
    reg = st.merge("plantations", {"mudah_my_sale": [old, sold]}, NOW)
    assert {i["id"] for i in st.active("plantations", reg, NOW)} == {"mudah:1", "mudah:2"}   # 200 days old stays
    # the site now shows mudah:2 as sold
    reg = st.merge("plantations", {"mudah_my_sale": [old, {"id": "mudah:2", "inactive": "sold"}]}, NOW + timedelta(hours=6))
    assert reg["mudah:2"]["removed_reason"] == "sold"
    assert [i["id"] for i in st.active("plantations", reg, NOW)] == ["mudah:1"]
    # a failed run, or one where the listing is simply absent once, removes nothing
    reg = st.merge("plantations", {}, NOW + timedelta(hours=12))
    reg = st.merge("plantations", {"mudah_my_sale": []}, NOW + timedelta(hours=18))
    assert reg["mudah:1"]["status"] == "active"


class ProbeHttp:
    def __init__(self, answers):
        self.answers, self.calls = answers, []

    def probe(self, url):
        self.calls.append(url)
        a = self.answers[url]
        if a == "blocked":
            raise Blocked("403")
        return a


def test_live_check_needs_two_agreeing_checks(tmp_path):
    st = Store(tmp_path, {})
    a = {**PLOT, "id": "mudah:11", "url": "https://www.mudah.my/a-1100001.htm", "source_date": NOW}
    b = {**PLOT, "id": "mudah:12", "url": "https://www.mudah.my/b-1200001.htm", "source_date": NOW, "area_acres": 9}
    c = {**PLOT, "id": "propertyguru:13", "url": "https://www.propertyguru.com.my/property-listing/c-13000001",
         "source": "propertyguru_my_sale", "source_date": NOW, "area_acres": 7}
    reg = st.merge("plantations", {"mudah_my_sale": [a, b], "propertyguru_my_sale": [c]}, NOW)
    http = ProbeHttp({a["url"]: (200, a["url"], "<h1>Oil palm land</h1>"),
                      b["url"]: (200, "https://www.mudah.my/malaysia/land-for-sale", "<h1>Search</h1>"),
                      c["url"]: "blocked"})
    cfg = {"recheck_after_hours": 24, "confirmations": 2}
    later = NOW + timedelta(hours=6)
    stats = verify.run(st, "plantations", reg, http, cfg, later)
    assert stats["live"] == 1 and stats["could_not_check"] == 1 and stats.get("pending_confirmation") == 1
    assert reg["mudah:12"]["status"] == "active"                     # one failed check is not enough
    stats = verify.run(st, "plantations", reg, http, cfg, later + timedelta(hours=6))
    assert reg["mudah:12"]["status"] == "removed" and reg["mudah:12"]["removed_reason"] == "no longer listed on the source site"
    assert reg["mudah:11"]["status"] == "active" and reg["propertyguru:13"]["status"] == "active"


def test_classify_markers():
    u = "https://www.mudah.my/tanah-sawit-116071305.htm"
    assert verify.classify(u, 404, u, "", [], []) .startswith("no longer")
    assert verify.classify(u, 200, u, "<p>Iklan ini telah dijual</p>", ["telah dijual"], []) == "sold"
    assert verify.classify(u, 200, u, "<script>var t='no longer available'</script><p>5 ekar</p>", [], ["no longer available"]) == "live"
