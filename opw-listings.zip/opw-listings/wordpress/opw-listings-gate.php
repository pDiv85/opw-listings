<?php
/**
 * Plugin Name: OPW Listings Gate
 * Description: Serves the Plantation Jobs / Plantations for Sale data to subscribers only, from a PRIVATE
 *              GitHub repository, and outputs the listings page with the [opw_listings] shortcode.
 * Version:     1.0.0
 *
 * Install: copy this file AND opw-listings.html into wp-content/mu-plugins/ (must-use plugins load
 * automatically), then add to wp-config.php:
 *
 *   define( 'OPW_LISTINGS_GH_REPO',   'your-org/opw-listings' );   // owner/repository
 *   define( 'OPW_LISTINGS_GH_BRANCH', 'main' );
 *   define( 'OPW_LISTINGS_GH_TOKEN',  'github_pat_…' );            // fine-grained token: this repo only,
 *                                                                   // Contents = Read-only
 *   define( 'OPW_LISTINGS_SUBSCRIBE_URL', '/subscribe/' );
 *
 * Who counts as a subscriber is decided by the 'opw_listings_can_view' filter. By default: any signed-in
 * user. Hook your paywall/membership plugin in, e.g. (pick the one OPW uses):
 *
 *   add_filter( 'opw_listings_can_view', fn() => function_exists( 'pmpro_hasMembershipLevel' ) && pmpro_hasMembershipLevel() );        // Paid Memberships Pro
 *   add_filter( 'opw_listings_can_view', fn() => current_user_can( 'mepr-active', 'memberships:123' ) );                              // MemberPress (membership ID)
 *   add_filter( 'opw_listings_can_view', fn() => function_exists( 'wc_memberships_is_user_active_member' ) && wc_memberships_is_user_active_member( get_current_user_id(), 'opw-premium' ) ); // WooCommerce Memberships
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function opw_listings_can_view() {
	return (bool) apply_filters( 'opw_listings_can_view', is_user_logged_in() );
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'opw/v1', '/listings/(?P<kind>jobs|plantations)', array(
		'methods'             => 'GET',
		'permission_callback' => 'opw_listings_can_view',
		'callback'            => 'opw_listings_rest',
	) );
} );

/**
 * Fetch data/<kind>.json from the private repo, cache it for 20 minutes, and keep the last good copy
 * so the page still works if GitHub is briefly unreachable.
 */
function opw_listings_rest( WP_REST_Request $req ) {
	$kind  = $req['kind'];
	$cache = 'opw_listings_' . $kind;
	$body  = get_transient( $cache );

	if ( false === $body ) {
		$url  = sprintf( 'https://api.github.com/repos/%s/contents/data/%s.json?ref=%s',
			OPW_LISTINGS_GH_REPO, $kind, rawurlencode( defined( 'OPW_LISTINGS_GH_BRANCH' ) ? OPW_LISTINGS_GH_BRANCH : 'main' ) );
		$resp = wp_remote_get( $url, array(
			'timeout' => 20,
			'headers' => array(
				'Authorization'        => 'Bearer ' . OPW_LISTINGS_GH_TOKEN,
				'Accept'               => 'application/vnd.github.raw+json',
				'X-GitHub-Api-Version' => '2022-11-28',
				'User-Agent'           => 'opw-listings-gate',
			),
		) );
		if ( ! is_wp_error( $resp ) && 200 === wp_remote_retrieve_response_code( $resp ) ) {
			$body = wp_remote_retrieve_body( $resp );
			set_transient( $cache, $body, 20 * MINUTE_IN_SECONDS );
			update_option( $cache . '_last_good', $body, false );
		} else {
			$body = get_option( $cache . '_last_good' );
			if ( ! $body ) {
				return new WP_Error( 'opw_listings_unavailable', 'Listings are temporarily unavailable.', array( 'status' => 503 ) );
			}
		}
	}

	$response = new WP_REST_Response( json_decode( $body, true ) );
	$response->header( 'Cache-Control', 'private, max-age=300' );
	return $response;
}

/**
 * [opw_listings] — subscribers get the listings page; everyone else gets a subscribe prompt.
 */
add_shortcode( 'opw_listings', function () {
	$subscribe = defined( 'OPW_LISTINGS_SUBSCRIBE_URL' ) ? OPW_LISTINGS_SUBSCRIBE_URL : '/subscribe/';
	if ( ! opw_listings_can_view() ) {
		return '<div class="opw-listings-locked" style="padding:18px;border:1px solid #dfe6e1;border-radius:8px;background:#f4f7f5">'
			. '<strong>Plantation Jobs and Plantations for Sale / Lease are for Oil Palm World subscribers.</strong><br>'
			. '<a href="' . esc_url( $subscribe ) . '">Subscribe or sign in</a> to browse the latest listings.</div>';
	}
	$config = array(
		'jobsUrl'        => esc_url_raw( rest_url( 'opw/v1/listings/jobs' ) ),
		'plantationsUrl' => esc_url_raw( rest_url( 'opw/v1/listings/plantations' ) ),
		'restNonce'      => wp_create_nonce( 'wp_rest' ),
		'subscribeUrl'   => esc_url_raw( $subscribe ),
	);
	$html = file_get_contents( __DIR__ . '/opw-listings.html' );
	return '<script>window.OPW_LISTINGS_CONFIG = ' . wp_json_encode( $config ) . ';</script>' . $html;
} );
