# Manual listings

Use these two CSV files for listings that no scraper reaches: broker emails, SMERGERS/DealStream leads,
Facebook groups, employer notices, or embassy and agency postings. Edit them on GitHub (pencil icon) or
in Excel (save as **CSV UTF-8**), then commit. Rows appear on the website after the next run.
- Jobs drop off 30 days after `listed_date`.
- Plantations stay up until you set the `status` column to `sold` or `withdrawn`, or delete the row.

**plantations.csv**: `title, deal (sale|lease), country, state, district, location, price, currency,
price_basis, area, tenure, property_type, agent, url, listed_date, source_name, status`

- `area` takes units as written, e.g. `250 acres`, `100 ha`, `92 manzanas`, `3 caballerías`
- `price` can be `RM 4,500,000`, `USD 1.2 million` or `Rp 15 miliar`
- `listed_date` is `YYYY-MM-DD`. If you leave it blank, the date the row is first picked up is used

**jobs.csv**: `title, company, country, state, district, location, salary, employment_type, url,
listed_date, source_name, summary`

Malaysia and Indonesia rows are grouped by state/province. Other countries are grouped by country.
